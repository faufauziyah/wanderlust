/**
 * WanderPulse Trip Planner & Itinerary Builder Module
 * Complete day-by-day scheduler, packing list manager, and itinerary exporter.
 */

const PlannerModule = {
  storageKey: "wanderpulse_trips_data",
  currentTripId: null,
  trips: [],

  init() {
    this.loadFromStorage();
    if (this.trips.length === 0) {
      this.createSampleTrip();
    }
    this.currentTripId = this.trips[0]?.id || null;
  },

  loadFromStorage() {
    try {
      const saved = localStorage.getItem(this.storageKey);
      if (saved) {
        this.trips = JSON.parse(saved);
      }
    } catch (e) {
      console.warn("Could not read trips from localStorage:", e);
      this.trips = [];
    }
  },

  saveToStorage() {
    try {
      localStorage.setItem(this.storageKey, JSON.stringify(this.trips));
    } catch (e) {
      console.warn("Could not save trips to localStorage:", e);
    }
  },

  getCurrentTrip() {
    return this.trips.find(t => t.id === this.currentTripId) || this.trips[0] || null;
  },

  createSampleTrip() {
    const sampleTrip = {
      id: "trip-" + Date.now(),
      title: "Kyoto Autumn Cultural Journey",
      destinationId: "kyoto-japan",
      destinationName: "Kyoto, Japan",
      startDate: "2026-10-15",
      endDate: "2026-10-21",
      daysCount: 7,
      travelers: 2,
      travelStyle: "midRange",
      budgetCapUSD: 3200,
      notes: "Focus on sunrise shrine photography, Michelin-starred matcha tea houses, and the Arashiyama bamboo path.",
      packingList: [
        { id: "p1", category: "Documents", text: "Passports & Japan Rail Pass voucher", done: true },
        { id: "p2", category: "Documents", text: "Travel health insurance confirmation", done: true },
        { id: "p3", category: "Tech", text: "Universal power adapter (Type A) & 20,000mAh power bank", done: true },
        { id: "p4", category: "Tech", text: "Mirrorless camera with wide prime lens", done: false },
        { id: "p5", category: "Clothing", text: "Ultra-comfortable walking shoes (slip-on for temples)", done: true },
        { id: "p6", category: "Clothing", text: "Packable rain jacket & lightweight fleece", done: false },
        { id: "p7", category: "Health", text: "Pocket hand sanitizer & blister bandages", done: false }
      ],
      days: [
        {
          dayNumber: 1,
          theme: "Arrival, Shinkansen Speed & Gion Geisha District",
          activities: [
            {
              id: "act-1",
              time: "Morning",
              category: "Transit",
              title: "Shinkansen Bullet Train from Tokyo to Kyoto",
              location: "Kyoto Station",
              costUSD: 95,
              notes: "Pick up bento box at Tokyo Station before boarding."
            },
            {
              id: "act-2",
              time: "Afternoon",
              category: "Leisure",
              title: "Check into traditional Machiya Guesthouse & Tea welcome",
              location: "Higashiyama Ward",
              costUSD: 0,
              notes: "Unpack and receive orientation map from host."
            },
            {
              id: "act-3",
              time: "Evening",
              category: "Food & Drink",
              title: "Twilight walking tour of Gion & Kaiseki Dinner",
              location: "Hanamikoji Street",
              costUSD: 65,
              notes: "Spot geikos heading to evening appointments; reserve table early."
            }
          ]
        },
        {
          dayNumber: 2,
          theme: "Torii Gates of Fushimi Inari & Sake Brewery District",
          activities: [
            {
              id: "act-4",
              time: "Morning",
              category: "Sightseeing",
              title: "Early Dawn Hike through 10,000 Vermilion Torii Gates",
              location: "Fushimi Inari-taisha",
              costUSD: 0,
              notes: "Arrive at 6:30 AM to capture clear photographs without crowds."
            },
            {
              id: "act-5",
              time: "Afternoon",
              category: "Food & Drink",
              title: "Fushimi Sake Tasting & Canal Boat Ride",
              location: "Gekkeikan Okura Sake Museum",
              costUSD: 25,
              notes: "Sample 5 regional junmai daiginjo sakes."
            },
            {
              id: "act-6",
              time: "Evening",
              category: "Food & Drink",
              title: "Street Food Feast at Nishiki Market",
              location: "Nishiki Market Arcade",
              costUSD: 30,
              notes: "Try octopus skewers with quail egg, soy milk donuts, and dashi tamagoyaki."
            }
          ]
        },
        {
          dayNumber: 3,
          theme: "Bamboo Whispers & Golden Pavilion Majesty",
          activities: [
            {
              id: "act-7",
              time: "Morning",
              category: "Sightseeing",
              title: "Arashiyama Bamboo Grove & Tenryu-ji Zen Garden",
              location: "Arashiyama",
              costUSD: 10,
              notes: "Walk through the soaring green canopy as morning wind rustles stalks."
            },
            {
              id: "act-8",
              time: "Afternoon",
              category: "Sightseeing",
              title: "Kinkaku-ji (The Golden Pavilion) Reflection Lake",
              location: "Kita Ward",
              costUSD: 8,
              notes: "Top two floors covered in genuine gold leaf reflecting on Kyoko-chi pond."
            },
            {
              id: "act-9",
              time: "Evening",
              category: "Leisure",
              title: "Traditional Onsen Bathing Experience",
              location: "Kurama Onsen",
              costUSD: 20,
              notes: "Relax in cedar open-air hot mineral bath overlooking forest."
            }
          ]
        }
      ]
    };

    this.trips.unshift(sampleTrip);
    this.saveToStorage();
  },

  createNewTrip({ title, destinationId, destinationName, startDate, endDate, travelers, travelStyle, budgetCapUSD }) {
    const start = new Date(startDate);
    const end = new Date(endDate);
    const diffTime = Math.abs(end - start);
    const daysCount = Math.max(1, Math.ceil(diffTime / (1000 * 60 * 60 * 24)) + 1);

    const newTrip = {
      id: "trip-" + Date.now(),
      title: title || `${destinationName} Trip`,
      destinationId,
      destinationName,
      startDate,
      endDate,
      daysCount,
      travelers: parseInt(travelers) || 1,
      travelStyle: travelStyle || "midRange",
      budgetCapUSD: parseInt(budgetCapUSD) || 2000,
      notes: "Excited to discover local highlights and culinary wonders!",
      packingList: [
        { id: "p1", category: "Documents", text: "Passports, IDs & Boarding Passes", done: false },
        { id: "p2", category: "Documents", text: "Hotel & Rental car reservations", done: false },
        { id: "p3", category: "Tech", text: "Phone chargers, cables & power banks", done: false },
        { id: "p4", category: "Clothing", text: "All-weather walking shoes & layers", done: false },
        { id: "p5", category: "Health", text: "First-aid essentials & daily medications", done: false }
      ],
      days: []
    };

    // Pre-generate day slots
    for (let i = 1; i <= daysCount; i++) {
      newTrip.days.push({
        dayNumber: i,
        theme: `Day ${i}: Exploration & Local Delights`,
        activities: []
      });
    }

    this.trips.unshift(newTrip);
    this.currentTripId = newTrip.id;
    this.saveToStorage();
    return newTrip;
  },

  deleteTrip(tripId) {
    this.trips = this.trips.filter(t => t.id !== tripId);
    if (this.currentTripId === tripId) {
      this.currentTripId = this.trips[0]?.id || null;
    }
    this.saveToStorage();
  },

  addActivity(tripId, dayNumber, activityData) {
    const trip = this.trips.find(t => t.id === tripId);
    if (!trip) return;

    let day = trip.days.find(d => d.dayNumber === dayNumber);
    if (!day) {
      day = { dayNumber, theme: `Day ${dayNumber}`, activities: [] };
      trip.days.push(day);
    }

    const activity = {
      id: "act-" + Date.now() + Math.random().toString(36).substr(2, 4),
      time: activityData.time || "Morning",
      category: activityData.category || "Sightseeing",
      title: activityData.title || "New Activity",
      location: activityData.location || "",
      costUSD: parseFloat(activityData.costUSD) || 0,
      notes: activityData.notes || ""
    };

    day.activities.push(activity);
    this.saveToStorage();
    return activity;
  },

  deleteActivity(tripId, dayNumber, activityId) {
    const trip = this.trips.find(t => t.id === tripId);
    if (!trip) return;

    const day = trip.days.find(d => d.dayNumber === dayNumber);
    if (day) {
      day.activities = day.activities.filter(a => a.id !== activityId);
      this.saveToStorage();
    }
  },

  togglePackingItem(tripId, itemId) {
    const trip = this.trips.find(t => t.id === tripId);
    if (!trip) return;

    const item = trip.packingList.find(i => i.id === itemId);
    if (item) {
      item.done = !item.done;
      this.saveToStorage();
    }
  },

  addPackingItem(tripId, category, text) {
    const trip = this.trips.find(t => t.id === tripId);
    if (!trip || !text.trim()) return;

    trip.packingList.push({
      id: "p-" + Date.now(),
      category: category || "General",
      text: text.trim(),
      done: false
    });
    this.saveToStorage();
  },

  deletePackingItem(tripId, itemId) {
    const trip = this.trips.find(t => t.id === tripId);
    if (!trip) return;

    trip.packingList = trip.packingList.filter(i => i.id !== itemId);
    this.saveToStorage();
  },

  calculateTotalActivitiesCost(trip) {
    if (!trip || !trip.days) return 0;
    let total = 0;
    trip.days.forEach(d => {
      d.activities.forEach(a => {
        total += (a.costUSD || 0);
      });
    });
    return total;
  },

  exportTripSummaryText(trip) {
    if (!trip) return "";
    let summary = `✈️ TRIP ITINERARY: ${trip.title}\n`;
    summary += `📍 Destination: ${trip.destinationName}\n`;
    summary += `📅 Dates: ${trip.startDate} to ${trip.endDate} (${trip.daysCount} Days)\n`;
    summary += `👥 Travelers: ${trip.travelers} | Style: ${trip.travelStyle.toUpperCase()}\n`;
    summary += `💰 Budget Target: $${trip.budgetCapUSD}\n`;
    summary += `--------------------------------------------------\n\n`;

    trip.days.forEach(day => {
      summary += `🌟 DAY ${day.dayNumber}: ${day.theme}\n`;
      if (day.activities.length === 0) {
        summary += `   (Open day for free wandering and relaxation)\n`;
      } else {
        day.activities.forEach(act => {
          summary += `   • [${act.time}] ${act.title} (${act.category}) - $${act.costUSD}\n`;
          if (act.location) summary += `     Location: ${act.location}\n`;
          if (act.notes) summary += `     Note: ${act.notes}\n`;
        });
      }
      summary += `\n`;
    });

    summary += `--------------------------------------------------\n`;
    summary += `🎒 PACKING CHECKLIST (${trip.packingList.filter(p => p.done).length}/${trip.packingList.length} packed):\n`;
    trip.packingList.forEach(item => {
      summary += `   [${item.done ? "✓" : " "}] ${item.text} (${item.category})\n`;
    });

    summary += `\nGenerated with WanderPulse Travel App`;
    return summary;
  }
};
