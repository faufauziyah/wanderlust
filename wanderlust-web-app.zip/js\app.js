/**
 * WanderPulse Main Application Controller
 * Connects the UI, state, modules, modals, search, and reactive views.
 */

const App = {
  activeTab: "finder",
  destinations: DESTINATIONS,
  filteredDestinations: [...DESTINATIONS],
  
  // Search & Filter State
  searchQuery: "",
  selectedContinent: "All",
  selectedVibe: "All",
  selectedSeason: "All",
  selectedBudgetTier: "All",
  selectedSort: "featured",

  // Current active destination in modal
  modalDestinationId: null,

  init() {
    // Initialize submodules
    PlannerModule.init();
    WishlistModule.init();

    // Bind event listeners
    this.bindEvents();

    // Render initial views
    this.applyFilters();
    this.renderHeaderCurrency();
    this.renderWishlistCount();

    // Initialize map if map container exists
    setTimeout(() => {
      MapModule.init(this.destinations);
    }, 100);

    // Run default recommendation to populate the Recommender tab immediately
    this.runBudgetRecommender();

    // Render planner
    this.renderPlanner();
  },

  bindEvents() {
    // Navigation Tabs
    document.querySelectorAll(".nav-tab-btn").forEach(btn => {
      btn.addEventListener("click", (e) => {
        const tab = e.currentTarget.dataset.tab;
        this.switchTab(tab);
      });
    });

    // Global Search
    const searchInput = document.getElementById("search-input");
    if (searchInput) {
      searchInput.addEventListener("input", (e) => {
        this.searchQuery = e.target.value.toLowerCase().trim();
        this.applyFilters();
      });
    }

    // Filter controls
    const continentFilter = document.getElementById("filter-continent");
    if (continentFilter) {
      continentFilter.addEventListener("change", (e) => {
        this.selectedContinent = e.target.value;
        this.applyFilters();
      });
    }

    const vibeFilter = document.getElementById("filter-vibe");
    if (vibeFilter) {
      vibeFilter.addEventListener("change", (e) => {
        this.selectedVibe = e.target.value;
        this.applyFilters();
      });
    }

    const seasonFilter = document.getElementById("filter-season");
    if (seasonFilter) {
      seasonFilter.addEventListener("change", (e) => {
        this.selectedSeason = e.target.value;
        this.applyFilters();
      });
    }

    const budgetTierFilter = document.getElementById("filter-budget-tier");
    if (budgetTierFilter) {
      budgetTierFilter.addEventListener("change", (e) => {
        this.selectedBudgetTier = e.target.value;
        this.applyFilters();
      });
    }

    const sortFilter = document.getElementById("filter-sort");
    if (sortFilter) {
      sortFilter.addEventListener("change", (e) => {
        this.selectedSort = e.target.value;
        this.applyFilters();
      });
    }

    // Currency selector
    const currencySelect = document.getElementById("currency-select");
    if (currencySelect) {
      currencySelect.addEventListener("change", (e) => {
        BudgetEngine.setCurrency(e.target.value);
        this.refreshAllPriceDisplays();
      });
    }

    // Modal close when clicking backdrop or ESC
    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape") {
        this.closeDestinationModal();
        this.closeNewTripModal();
        this.closeNewActivityModal();
      }
    });
  },

  switchTab(tabName) {
    this.activeTab = tabName;

    // Update active nav button styles
    document.querySelectorAll(".nav-tab-btn").forEach(btn => {
      const isActive = btn.dataset.tab === tabName;
      btn.classList.toggle("text-indigo-600", isActive);
      btn.classList.toggle("border-indigo-600", isActive);
      btn.classList.toggle("border-b-2", isActive);
      btn.classList.toggle("font-semibold", isActive);
      btn.classList.toggle("text-slate-600", !isActive);
      btn.classList.toggle("font-medium", !isActive);
    });

    // Update tab view visibility
    document.querySelectorAll(".tab-content-panel").forEach(panel => {
      panel.classList.toggle("hidden", panel.id !== `tab-panel-${tabName}`);
    });

    // Tab specific refresh actions
    if (tabName === "map") {
      setTimeout(() => {
        if (MapModule.mapInstance) {
          MapModule.mapInstance.invalidateSize();
        }
      }, 150);
    } else if (tabName === "wishlist") {
      this.renderWishlistView();
    } else if (tabName === "planner") {
      this.renderPlanner();
    }
  },

  applyFilters() {
    this.filteredDestinations = this.destinations.filter(dest => {
      // Search matching
      const matchesSearch = !this.searchQuery ||
        dest.name.toLowerCase().includes(this.searchQuery) ||
        dest.country.toLowerCase().includes(this.searchQuery) ||
        dest.continent.toLowerCase().includes(this.searchQuery) ||
        dest.tagline.toLowerCase().includes(this.searchQuery) ||
        dest.vibes.some(v => v.toLowerCase().includes(this.searchQuery)) ||
        dest.highlights.some(h => h.toLowerCase().includes(this.searchQuery));

      // Continent matching
      const matchesContinent = this.selectedContinent === "All" || dest.continent === this.selectedContinent;

      // Vibe matching
      const matchesVibe = this.selectedVibe === "All" || dest.vibes.includes(this.selectedVibe);

      // Season matching
      const matchesSeason = this.selectedSeason === "All" || dest.bestSeasons.includes(this.selectedSeason);

      // Budget Tier matching
      const matchesBudget = this.selectedBudgetTier === "All" || dest.budgetTier === this.selectedBudgetTier;

      return matchesSearch && matchesContinent && matchesVibe && matchesSeason && matchesBudget;
    });

    // Sorting
    if (this.selectedSort === "cost-asc") {
      this.filteredDestinations.sort((a, b) => {
        const costA = a.dailyCostsUSD.midRange.lodging + a.dailyCostsUSD.midRange.food;
        const costB = b.dailyCostsUSD.midRange.lodging + b.dailyCostsUSD.midRange.food;
        return costA - costB;
      });
    } else if (this.selectedSort === "cost-desc") {
      this.filteredDestinations.sort((a, b) => {
        const costA = a.dailyCostsUSD.midRange.lodging + a.dailyCostsUSD.midRange.food;
        const costB = b.dailyCostsUSD.midRange.lodging + b.dailyCostsUSD.midRange.food;
        return costB - costA;
      });
    } else if (this.selectedSort === "safety") {
      this.filteredDestinations.sort((a, b) => b.safetyRating - a.safetyRating);
    } else if (this.selectedSort === "name") {
      this.filteredDestinations.sort((a, b) => a.name.localeCompare(b.name));
    }

    this.renderDestinationsGrid();
  },

  resetFilters() {
    this.searchQuery = "";
    this.selectedContinent = "All";
    this.selectedVibe = "All";
    this.selectedSeason = "All";
    this.selectedBudgetTier = "All";
    this.selectedSort = "featured";

    const searchInput = document.getElementById("search-input");
    if (searchInput) searchInput.value = "";
    const filterContinent = document.getElementById("filter-continent");
    if (filterContinent) filterContinent.value = "All";
    const filterVibe = document.getElementById("filter-vibe");
    if (filterVibe) filterVibe.value = "All";
    const filterSeason = document.getElementById("filter-season");
    if (filterSeason) filterSeason.value = "All";
    const filterBudgetTier = document.getElementById("filter-budget-tier");
    if (filterBudgetTier) filterBudgetTier.value = "All";
    const filterSort = document.getElementById("filter-sort");
    if (filterSort) filterSort.value = "featured";

    this.applyFilters();
    this.showToast("Filters reset to default view");
  },

  renderDestinationsGrid() {
    const grid = document.getElementById("destinations-grid");
    const countBadge = document.getElementById("destinations-count-badge");
    if (!grid) return;

    if (countBadge) {
      countBadge.textContent = `${this.filteredDestinations.length} destinations found`;
    }

    if (this.filteredDestinations.length === 0) {
      grid.innerHTML = `
        <div class="col-span-full py-16 text-center">
          <div class="w-16 h-16 mx-auto mb-4 bg-indigo-50 text-indigo-500 rounded-full flex items-center justify-center">
            <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg>
          </div>
          <h3 class="text-lg font-bold text-slate-800">No destinations match your criteria</h3>
          <p class="text-sm text-slate-500 max-w-md mx-auto mt-1 mb-4">Try relaxing your filters or resetting the search term to view global recommendations.</p>
          <button onclick="App.resetFilters()" class="inline-flex items-center gap-2 bg-indigo-600 text-white font-medium px-4 py-2 rounded-lg text-sm hover:bg-indigo-700 transition">
            Reset Filters
          </button>
        </div>
      `;
      return;
    }

    grid.innerHTML = this.filteredDestinations.map(dest => {
      const isSaved = WishlistModule.isWishlisted(dest.id);
      const midDayCost = dest.dailyCostsUSD.midRange.lodging + dest.dailyCostsUSD.midRange.food;
      const formattedCost = BudgetEngine.formatCurrency(midDayCost);

      return `
        <div class="group bg-white rounded-2xl overflow-hidden border border-slate-200/80 shadow-sm hover:shadow-xl hover:-translate-y-1 transition duration-300 flex flex-col">
          <!-- Card Image Container -->
          <div class="relative h-52 w-full overflow-hidden bg-slate-100 cursor-pointer" onclick="App.openDestinationModal('${dest.id}')">
            <img 
              src="${dest.image}" 
              alt="${dest.name}" 
              loading="lazy"
              class="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" 
            />
            <div class="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent"></div>

            <!-- Top Left: Continent Badge -->
            <span class="absolute top-3 left-3 bg-white/90 backdrop-blur-md text-slate-800 text-xs font-semibold px-2.5 py-1 rounded-full shadow-sm">
              ${dest.continent}
            </span>

            <!-- Top Right: Wishlist Button -->
            <button 
              onclick="event.stopPropagation(); App.toggleWishlist('${dest.id}')" 
              class="absolute top-3 right-3 w-9 h-9 rounded-full bg-white/90 backdrop-blur-md flex items-center justify-center text-slate-700 hover:text-rose-500 hover:scale-110 shadow-sm transition"
              title="${isSaved ? 'Remove from Wishlist' : 'Add to Wishlist'}"
            >
              <svg class="w-5 h-5 ${isSaved ? 'fill-rose-500 text-rose-500' : 'fill-none stroke-current'}" viewBox="0 0 24 24" stroke-width="2">
                <path stroke-linecap="round" stroke-linejoin="round" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"></path>
              </svg>
            </button>

            <!-- Bottom Left: Name & Country -->
            <div class="absolute bottom-3 left-3 right-3 text-white">
              <div class="flex items-center gap-1.5 text-xs text-sky-200 mb-0.5">
                <svg class="w-3.5 h-3.5 fill-current" viewBox="0 0 24 24"><path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z"/></svg>
                <span>${dest.country}</span>
              </div>
              <h3 class="text-xl font-bold leading-tight drop-shadow-sm">${dest.name}</h3>
            </div>
          </div>

          <!-- Card Content Body -->
          <div class="p-4 flex-1 flex flex-col justify-between">
            <div>
              <p class="text-xs text-slate-600 line-clamp-2 mb-3">${dest.tagline}</p>

              <!-- Vibes tags -->
              <div class="flex flex-wrap gap-1.5 mb-3">
                ${dest.vibes.slice(0, 3).map(vibe => `
                  <span class="inline-block bg-slate-100 hover:bg-slate-200 text-slate-600 text-[11px] font-medium px-2 py-0.5 rounded-md transition">
                    ${vibe}
                  </span>
                `).join("")}
              </div>
            </div>

            <!-- Card Footer: Cost & Action -->
            <div class="pt-3 border-t border-slate-100 flex items-center justify-between">
              <div>
                <span class="text-[10px] text-slate-400 uppercase tracking-wider block font-semibold">Avg Mid-range</span>
                <span class="text-sm font-bold text-indigo-600">${formattedCost}</span>
                <span class="text-[11px] text-slate-500">/day</span>
              </div>

              <div class="flex items-center gap-1.5">
                <button 
                  onclick="App.viewOnMap('${dest.id}')" 
                  class="p-2 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition" 
                  title="View on Map"
                >
                  <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7"></path></svg>
                </button>
                <button 
                  onclick="App.openDestinationModal('${dest.id}')" 
                  class="bg-indigo-50 hover:bg-indigo-600 hover:text-white text-indigo-700 text-xs font-semibold px-3 py-1.5 rounded-lg transition"
                >
                  Details
                </button>
              </div>
            </div>
          </div>
        </div>
      `;
    }).join("");
  },

  openDestinationModal(destId) {
    const dest = this.destinations.find(d => d.id === destId);
    if (!dest) return;
    this.modalDestinationId = destId;

    const modal = document.getElementById("destination-modal");
    const container = document.getElementById("destination-modal-content");
    if (!modal || !container) return;

    const isSaved = WishlistModule.isWishlisted(dest.id);
    const bCosts = dest.dailyCostsUSD.backpacker;
    const mCosts = dest.dailyCostsUSD.midRange;
    const lCosts = dest.dailyCostsUSD.luxury;

    container.innerHTML = `
      <div class="relative bg-white rounded-2xl overflow-hidden max-w-3xl w-full shadow-2xl border border-slate-200 max-h-[90vh] flex flex-col">
        <!-- Modal Header Image -->
        <div class="relative h-64 sm:h-72 w-full overflow-hidden bg-slate-900 flex-shrink-0">
          <img src="${dest.image}" alt="${dest.name}" class="w-full h-full object-cover opacity-90" />
          <div class="absolute inset-0 bg-gradient-to-t from-black/85 via-black/40 to-black/20"></div>

          <!-- Close Button -->
          <button onclick="App.closeDestinationModal()" class="absolute top-4 right-4 w-9 h-9 rounded-full bg-black/40 text-white hover:bg-black/70 flex items-center justify-center transition">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>
          </button>

          <!-- Top Meta Badges -->
          <div class="absolute top-4 left-4 flex gap-2">
            <span class="bg-indigo-600/90 backdrop-blur-md text-white text-xs font-bold px-3 py-1 rounded-full shadow">
              ${dest.continent}
            </span>
            <span class="bg-emerald-600/90 backdrop-blur-md text-white text-xs font-bold px-3 py-1 rounded-full shadow flex items-center gap-1">
              ★ ${dest.safetyRating} Safety
            </span>
          </div>

          <!-- Title Overlay -->
          <div class="absolute bottom-4 left-6 right-6 text-white">
            <p class="text-xs font-semibold text-sky-300 tracking-wide uppercase">${dest.country} &bull; Best Seasons: ${dest.bestSeasons.join(", ")}</p>
            <h2 class="text-3xl font-extrabold tracking-tight">${dest.name}</h2>
            <p class="text-sm text-slate-200 mt-1 line-clamp-1">${dest.tagline}</p>
          </div>
        </div>

        <!-- Scrollable Modal Body -->
        <div class="p-6 overflow-y-auto space-y-6 flex-1 text-slate-700 text-sm">
          <!-- Overview -->
          <div>
            <h4 class="font-bold text-slate-900 text-base mb-1.5 flex items-center gap-2">
              <span class="w-2 h-2 rounded-full bg-indigo-600"></span> About this Destination
            </h4>
            <p class="leading-relaxed text-slate-600">${dest.description}</p>
          </div>

          <!-- Daily Budget Breakdown Table -->
          <div class="bg-slate-50 p-4 rounded-xl border border-slate-200">
            <div class="flex items-center justify-between mb-3">
              <h4 class="font-bold text-slate-900 text-sm flex items-center gap-2">
                <svg class="w-4 h-4 text-emerald-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                Estimated Daily Cost by Style (Per Person)
              </h4>
              <span class="text-xs text-slate-500">Base Flight: ~${BudgetEngine.formatCurrency(dest.baseFlightEstUSD)}</span>
            </div>

            <div class="grid grid-cols-3 gap-2 text-center text-xs">
              <!-- Backpacker -->
              <div class="bg-white p-3 rounded-lg border border-slate-200 shadow-sm">
                <span class="font-bold text-slate-700 block text-xs">Backpacker ($)</span>
                <span class="text-base font-extrabold text-emerald-600 my-1 block">
                  ${BudgetEngine.formatCurrency(bCosts.lodging + bCosts.food + bCosts.transport + bCosts.activities)}/day
                </span>
                <span class="text-[11px] text-slate-500 block">Hostel + Street food</span>
              </div>

              <!-- Mid-range (Featured) -->
              <div class="bg-indigo-50/70 p-3 rounded-lg border-2 border-indigo-400 shadow-sm relative">
                <span class="absolute -top-2 left-1/2 -translate-x-1/2 bg-indigo-600 text-white text-[9px] font-bold px-1.5 py-0.2 rounded-full">POPULAR</span>
                <span class="font-bold text-indigo-900 block text-xs">Mid-Range ($$)</span>
                <span class="text-base font-extrabold text-indigo-700 my-1 block">
                  ${BudgetEngine.formatCurrency(mCosts.lodging + mCosts.food + mCosts.transport + mCosts.activities)}/day
                </span>
                <span class="text-[11px] text-indigo-600 block">3-4★ Hotel + Cafes</span>
              </div>

              <!-- Luxury -->
              <div class="bg-white p-3 rounded-lg border border-slate-200 shadow-sm">
                <span class="font-bold text-slate-700 block text-xs">Luxury ($$$$)</span>
                <span class="text-base font-extrabold text-amber-600 my-1 block">
                  ${BudgetEngine.formatCurrency(lCosts.lodging + lCosts.food + lCosts.transport + lCosts.activities)}/day
                </span>
                <span class="text-[11px] text-slate-500 block">5★ Resort + Fine dining</span>
              </div>
            </div>
          </div>

          <!-- Must-Do Highlights & Local Eats in 2 columns -->
          <div class="grid sm:grid-cols-2 gap-4">
            <!-- Highlights -->
            <div class="bg-white p-4 rounded-xl border border-slate-200">
              <h5 class="font-bold text-slate-900 text-xs mb-2.5 flex items-center gap-1.5 text-indigo-600">
                <svg class="w-4 h-4 fill-current" viewBox="0 0 24 24"><path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z"/></svg>
                Top Must-Do Highlights
              </h5>
              <ul class="space-y-1.5 text-xs text-slate-600">
                ${dest.highlights.map(h => `<li class="flex items-start gap-2"><span class="text-indigo-500 font-bold">•</span><span>${h}</span></li>`).join("")}
              </ul>
            </div>

            <!-- Cuisine -->
            <div class="bg-white p-4 rounded-xl border border-slate-200">
              <h5 class="font-bold text-slate-900 text-xs mb-2.5 flex items-center gap-1.5 text-amber-600">
                <svg class="w-4 h-4 fill-current" viewBox="0 0 24 24"><path d="M11 9H9V2H7v7H5V2H3v7c0 2.12 1.66 3.84 3.75 3.97V22h2.5v-9.03C11.34 12.84 13 11.12 13 9V2h-2v7zm5-3v8h2.5v8H21V2c-2.76 0-5 2.24-5 4z"/></svg>
                Famous Local Cuisine
              </h5>
              <ul class="space-y-1.5 text-xs text-slate-600">
                ${dest.localCuisine.map(c => `<li class="flex items-start gap-2"><span class="text-amber-500 font-bold">•</span><span>${c}</span></li>`).join("")}
              </ul>
            </div>
          </div>

          <!-- Insider Tip -->
          <div class="bg-amber-50/80 border-l-4 border-amber-500 p-3 rounded-r-xl text-xs text-amber-900">
            <span class="font-bold block mb-0.5">💡 Local Insider Tip:</span>
            ${dest.localTips}
          </div>
        </div>

        <!-- Modal Footer Actions -->
        <div class="p-4 bg-slate-50 border-t border-slate-200 flex flex-wrap items-center justify-between gap-3">
          <div class="flex items-center gap-2">
            <button 
              onclick="App.toggleWishlist('${dest.id}'); App.openDestinationModal('${dest.id}');"
              class="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-semibold border ${isSaved ? 'bg-rose-50 border-rose-300 text-rose-600' : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-100'} transition"
            >
              <svg class="w-4 h-4 ${isSaved ? 'fill-rose-500' : 'fill-none stroke-current'}" viewBox="0 0 24 24" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"></path></svg>
              <span>${isSaved ? 'Saved to Wishlist' : 'Add to Wishlist'}</span>
            </button>

            <button 
              onclick="App.closeDestinationModal(); App.viewOnMap('${dest.id}');"
              class="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold bg-white border border-slate-200 text-slate-700 hover:bg-slate-100 transition"
            >
              <svg class="w-4 h-4 text-sky-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"></path></svg>
              <span>View Map</span>
            </button>
          </div>

          <div class="flex items-center gap-2">
            <button 
              onclick="App.closeDestinationModal(); App.openBudgetWithDestination('${dest.id}');"
              class="px-4 py-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 rounded-xl text-xs font-semibold transition"
            >
              Estimate Budget
            </button>
            <button 
              onclick="App.closeDestinationModal(); App.quickPlanTrip('${dest.id}');"
              class="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow-md shadow-indigo-200 transition"
            >
              Plan Trip Here
            </button>
          </div>
        </div>
      </div>
    `;

    modal.classList.remove("hidden");
    document.body.classList.add("overflow-hidden");
  },

  closeDestinationModal() {
    const modal = document.getElementById("destination-modal");
    if (modal) {
      modal.classList.add("hidden");
      document.body.classList.remove("overflow-hidden");
    }
  },

  viewOnMap(destId) {
    this.switchTab("map");
    setTimeout(() => {
      MapModule.flyToDestination(destId);
    }, 200);
  },

  toggleWishlist(destId) {
    const result = WishlistModule.toggleWishlist(destId);
    const dest = this.destinations.find(d => d.id === destId);
    const name = dest ? dest.name : "Destination";

    if (result.added) {
      this.showToast(`❤️ Added ${name} to your Wishlist!`);
    } else {
      this.showToast(`Removed ${name} from your Wishlist`);
    }

    this.renderWishlistCount();
    this.applyFilters();
    if (this.activeTab === "wishlist") {
      this.renderWishlistView();
    }
  },

  renderWishlistCount() {
    const countBadge = document.getElementById("header-wishlist-count");
    if (countBadge) {
      const count = WishlistModule.items.filter(i => i.status === "wishlist").length;
      countBadge.textContent = count;
      countBadge.classList.toggle("hidden", count === 0);
    }
  },

  renderHeaderCurrency() {
    const select = document.getElementById("currency-select");
    if (select) {
      select.value = BudgetEngine.currentCurrency;
    }
  },

  refreshAllPriceDisplays() {
    this.renderDestinationsGrid();
    if (this.activeTab === "wishlist") this.renderWishlistView();
    if (this.activeTab === "planner") this.renderPlanner();
    this.runBudgetRecommender();
    this.runGranularEstimator();
  },

  /* ==============================================================
     BUDGET ENGINE & RECOMMENDATION UI
     ============================================================== */
  runBudgetRecommender() {
    const budgetInput = document.getElementById("rec-budget-input");
    const daysSelect = document.getElementById("rec-days-select");
    const travelersSelect = document.getElementById("rec-travelers-select");
    const styleSelect = document.getElementById("rec-style-select");
    const vibeSelect = document.getElementById("rec-vibe-select");
    const flightsCheck = document.getElementById("rec-flights-check");

    const userBudgetUSD = parseFloat(budgetInput?.value) || 2500;
    const days = parseInt(daysSelect?.value) || 7;
    const travelers = parseInt(travelersSelect?.value) || 1;
    const travelStyle = styleSelect?.value || "any";
    const preferredVibe = vibeSelect?.value || "All";
    const includeFlights = flightsCheck ? flightsCheck.checked : true;

    // Display formatted budget in input label
    const budgetLabel = document.getElementById("rec-budget-display");
    if (budgetLabel) {
      budgetLabel.textContent = BudgetEngine.formatCurrency(userBudgetUSD);
    }

    const recommendations = BudgetEngine.recommendDestinations({
      userBudgetUSD,
      days,
      travelers,
      travelStyle,
      preferredVibe,
      includeFlights
    });

    const resultsContainer = document.getElementById("budget-recs-container");
    if (!resultsContainer) return;

    if (recommendations.length === 0) {
      resultsContainer.innerHTML = `
        <div class="text-center py-12 text-slate-500">
          <p>No matching destinations found for this budget. Try increasing your budget or duration.</p>
        </div>
      `;
      return;
    }

    // Top #1 Champion Match
    const topPick = recommendations[0];
    const topDest = topPick.destination;
    const topCost = topPick.costEstimate;

    // Runner-ups
    const runnerUps = recommendations.slice(1, 4);

    resultsContainer.innerHTML = `
      <!-- TOP CHAMPION RECOMMENDATION CARD -->
      <div class="relative bg-gradient-to-br from-indigo-900 via-slate-900 to-sky-950 rounded-3xl p-6 sm:p-8 text-white shadow-2xl border border-indigo-500/30 overflow-hidden mb-8">
        <!-- Background Ambient Glow & Graphic -->
        <div class="absolute -right-16 -top-16 w-80 h-80 rounded-full bg-indigo-500/10 blur-3xl pointer-events-none"></div>
        <div class="absolute -left-16 -bottom-16 w-80 h-80 rounded-full bg-sky-500/10 blur-3xl pointer-events-none"></div>

        <!-- Top Badge Banner -->
        <div class="flex flex-wrap items-center justify-between gap-3 mb-6">
          <div class="inline-flex items-center gap-2 bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 font-black text-xs uppercase tracking-wider px-3.5 py-1.5 rounded-full shadow-lg">
            <span>👑 #1 BEST VALUE DESTINATION FOR YOUR BUDGET</span>
          </div>

          <div class="flex items-center gap-2">
            <span class="text-xs text-sky-200 font-semibold">Match Score:</span>
            <div class="inline-flex items-center justify-center bg-emerald-500 text-white font-extrabold text-sm px-3 py-1 rounded-xl shadow">
              ${topPick.matchScore}% Match
            </div>
          </div>
        </div>

        <!-- Main Champion Split -->
        <div class="grid lg:grid-cols-12 gap-6 items-center">
          <!-- Left: Image & Quick Meta -->
          <div class="lg:col-span-5 relative rounded-2xl overflow-hidden aspect-[4/3] shadow-lg group cursor-pointer" onclick="App.openDestinationModal('${topDest.id}')">
            <img src="${topDest.image}" alt="${topDest.name}" class="w-full h-full object-cover transition duration-500 group-hover:scale-105" />
            <div class="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent"></div>
            <div class="absolute bottom-4 left-4 right-4">
              <span class="text-xs text-sky-300 font-medium">${topDest.country} &bull; ${topDest.continent}</span>
              <h3 class="text-2xl font-black">${topDest.name}</h3>
            </div>
          </div>

          <!-- Right: Cost Breakdown & Recommendation Logic -->
          <div class="lg:col-span-7 space-y-4">
            <div>
              <div class="flex flex-wrap items-baseline gap-3">
                <span class="text-3xl font-black text-emerald-400">
                  ${BudgetEngine.formatCurrency(topCost.grandTotalUSD)}
                </span>
                <span class="text-xs text-slate-300 font-medium">
                  Total for ${days} days &bull; ${travelers} traveler(s) &bull; ${topPick.recommendedStyle.toUpperCase()} style
                </span>
              </div>

              <!-- Budget Surplus / Verdict Pill -->
              <div class="mt-2 inline-flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-semibold ${topPick.isUnderBudget ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40' : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'}">
                <span>${topPick.budgetVerdict}: ${topPick.recommendationReason}</span>
              </div>
            </div>

            <!-- Visual Cost Progress Bar Breakdown -->
            <div class="space-y-2 bg-white/5 p-4 rounded-xl border border-white/10 backdrop-blur-sm text-xs">
              <span class="font-bold text-slate-200 block text-[11px] uppercase tracking-wider">Detailed Expense Breakdown</span>
              <div class="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1">
                <div class="bg-white/5 p-2 rounded-lg">
                  <span class="text-[10px] text-slate-400 block">✈️ Flights</span>
                  <span class="font-bold text-slate-100">${BudgetEngine.formatCurrency(topCost.breakdownUSD.flights)}</span>
                </div>
                <div class="bg-white/5 p-2 rounded-lg">
                  <span class="text-[10px] text-slate-400 block">🏨 Lodging</span>
                  <span class="font-bold text-slate-100">${BudgetEngine.formatCurrency(topCost.breakdownUSD.lodging)}</span>
                </div>
                <div class="bg-white/5 p-2 rounded-lg">
                  <span class="text-[10px] text-slate-400 block">🍜 Food & Dining</span>
                  <span class="font-bold text-slate-100">${BudgetEngine.formatCurrency(topCost.breakdownUSD.food)}</span>
                </div>
                <div class="bg-white/5 p-2 rounded-lg">
                  <span class="text-[10px] text-slate-400 block">🎟️ Activities & Transit</span>
                  <span class="font-bold text-slate-100">${BudgetEngine.formatCurrency(topCost.breakdownUSD.transport + topCost.breakdownUSD.activities)}</span>
                </div>
              </div>
            </div>

            <!-- Action Buttons -->
            <div class="flex flex-wrap items-center gap-3 pt-2">
              <button 
                onclick="App.quickPlanTrip('${topDest.id}', ${days}, ${travelers}, '${topPick.recommendedStyle}', ${userBudgetUSD})" 
                class="flex-1 min-w-[160px] bg-gradient-to-r from-indigo-500 to-sky-500 hover:from-indigo-600 hover:to-sky-600 text-white font-bold py-3 px-5 rounded-xl shadow-lg transition text-center text-sm"
              >
                Plan Itinerary for ${topDest.name}
              </button>
              <button 
                onclick="App.openDestinationModal('${topDest.id}')" 
                class="bg-white/10 hover:bg-white/20 text-white font-semibold py-3 px-4 rounded-xl transition text-sm"
              >
                Explore Details
              </button>
              <button 
                onclick="App.toggleWishlist('${topDest.id}')" 
                class="p-3 bg-white/10 hover:bg-rose-500/20 text-white hover:text-rose-400 rounded-xl transition"
                title="Save to Wishlist"
              >
                <svg class="w-5 h-5 fill-current" viewBox="0 0 24 24"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg>
              </button>
            </div>
          </div>
        </div>
      </div>

      <!-- RUNNER-UP RECOMMENDATION CARDS -->
      <div class="mb-6">
        <h3 class="text-base font-bold text-slate-900 mb-4 flex items-center gap-2">
          <svg class="w-5 h-5 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
          Alternative High-Value Matches for Your Budget
        </h3>

        <div class="grid md:grid-cols-3 gap-4">
          ${runnerUps.map((rec, idx) => {
            const d = rec.destination;
            const cost = rec.costEstimate;
            const rankLabel = idx === 0 ? "🥈 2nd Best Value" : idx === 1 ? "🥉 3rd Alternative" : "✨ Great Alternative";

            return `
              <div class="bg-white rounded-2xl p-4 border border-slate-200 shadow-sm hover:shadow-md transition flex flex-col justify-between">
                <div>
                  <div class="relative h-36 rounded-xl overflow-hidden mb-3">
                    <img src="${d.image}" alt="${d.name}" class="w-full h-full object-cover" />
                    <span class="absolute top-2 left-2 bg-black/60 text-white text-[10px] font-bold px-2 py-0.5 rounded-full">
                      ${rankLabel}
                    </span>
                    <span class="absolute top-2 right-2 bg-emerald-600 text-white text-[10px] font-bold px-2 py-0.5 rounded shadow">
                      ${rec.matchScore}% Match
                    </span>
                  </div>

                  <h4 class="font-bold text-base text-slate-900 leading-snug">${d.name}</h4>
                  <p class="text-xs text-slate-500 mb-2">${d.country} &bull; ${d.vibes.slice(0, 2).join(", ")}</p>

                  <div class="flex items-baseline gap-2 mb-2">
                    <span class="text-lg font-extrabold text-slate-900">${BudgetEngine.formatCurrency(cost.grandTotalUSD)}</span>
                    <span class="text-[11px] text-slate-500">total est.</span>
                  </div>

                  <p class="text-[11px] text-slate-600 line-clamp-2 mb-3 bg-slate-50 p-2 rounded-lg border border-slate-100">
                    ${rec.recommendationReason}
                  </p>
                </div>

                <div class="pt-2 border-t border-slate-100 flex items-center gap-2">
                  <button onclick="App.openDestinationModal('${d.id}')" class="flex-1 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold py-2 rounded-lg transition">
                    Details
                  </button>
                  <button onclick="App.quickPlanTrip('${d.id}', ${days}, ${travelers}, '${rec.recommendedStyle}', ${userBudgetUSD})" class="bg-indigo-50 hover:bg-indigo-600 hover:text-white text-indigo-600 text-xs font-semibold py-2 px-3 rounded-lg transition">
                    Plan
                  </button>
                </div>
              </div>
            `;
          }).join("")}
        </div>
      </div>
    `;

    // Trigger celebration confetti if canvas-confetti is loaded
    if (typeof confetti === "function") {
      confetti({
        particleCount: 40,
        spread: 60,
        origin: { y: 0.6 }
      });
    }
  },

  openBudgetWithDestination(destId) {
    this.switchTab("budget");
    const destSelect = document.getElementById("gran-dest-select");
    if (destSelect) {
      destSelect.value = destId;
      this.runGranularEstimator();
    }
  },

  runGranularEstimator() {
    const destSelect = document.getElementById("gran-dest-select");
    const daysInput = document.getElementById("gran-days-input");
    const travelersInput = document.getElementById("gran-travelers-input");
    const styleSelect = document.getElementById("gran-style-select");
    const flightsCheck = document.getElementById("gran-flights-check");

    const destinationId = destSelect?.value || DESTINATIONS[0].id;
    const days = parseInt(daysInput?.value) || 7;
    const travelers = parseInt(travelersInput?.value) || 2;
    const travelStyle = styleSelect?.value || "midRange";
    const includeFlights = flightsCheck ? flightsCheck.checked : true;

    const cost = BudgetEngine.calculateTripCost({
      destinationId,
      days,
      travelers,
      travelStyle,
      includeFlights
    });

    if (!cost) return;

    // Update displays
    const totalDisplay = document.getElementById("gran-total-display");
    const perPersonDisplay = document.getElementById("gran-per-person-display");
    const flightDisplay = document.getElementById("gran-flight-display");
    const lodgingDisplay = document.getElementById("gran-lodging-display");
    const foodDisplay = document.getElementById("gran-food-display");
    const transportDisplay = document.getElementById("gran-transport-display");
    const actDisplay = document.getElementById("gran-act-display");
    const bufferDisplay = document.getElementById("gran-buffer-display");

    if (totalDisplay) totalDisplay.textContent = BudgetEngine.formatCurrency(cost.grandTotalUSD);
    if (perPersonDisplay) perPersonDisplay.textContent = `${BudgetEngine.formatCurrency(cost.dailyPerPersonUSD)}/day/person`;
    if (flightDisplay) flightDisplay.textContent = BudgetEngine.formatCurrency(cost.breakdownUSD.flights);
    if (lodgingDisplay) lodgingDisplay.textContent = BudgetEngine.formatCurrency(cost.breakdownUSD.lodging);
    if (foodDisplay) foodDisplay.textContent = BudgetEngine.formatCurrency(cost.breakdownUSD.food);
    if (transportDisplay) transportDisplay.textContent = BudgetEngine.formatCurrency(cost.breakdownUSD.transport);
    if (actDisplay) actDisplay.textContent = BudgetEngine.formatCurrency(cost.breakdownUSD.activities);
    if (bufferDisplay) bufferDisplay.textContent = BudgetEngine.formatCurrency(cost.breakdownUSD.buffer);
  },

  /* ==============================================================
     TRIP PLANNER UI
     ============================================================== */
  quickPlanTrip(destId, days = 7, travelers = 2, style = "midRange", budget = 2500) {
    const dest = this.destinations.find(d => d.id === destId);
    if (!dest) return;

    const startDate = new Date();
    startDate.setDate(startDate.getDate() + 30);
    const endDate = new Date(startDate);
    endDate.setDate(endDate.getDate() + (days - 1));

    const newTrip = PlannerModule.createNewTrip({
      title: `${dest.name} Adventure`,
      destinationId: dest.id,
      destinationName: `${dest.name}, ${dest.country}`,
      startDate: startDate.toISOString().split("T")[0],
      endDate: endDate.toISOString().split("T")[0],
      travelers,
      travelStyle: style,
      budgetCapUSD: budget
    });

    // Populate day 1 with a starter activity from highlights
    if (dest.highlights && dest.highlights.length > 0) {
      PlannerModule.addActivity(newTrip.id, 1, {
        time: "Morning",
        category: "Sightseeing",
        title: `Explore ${dest.highlights[0]}`,
        location: dest.name,
        costUSD: 25,
        notes: "Visit early morning for the best photos and serene atmosphere."
      });
    }

    this.showToast(`✈️ Trip itinerary initialized for ${dest.name}!`);
    this.switchTab("planner");
  },

  renderPlanner() {
    const trip = PlannerModule.getCurrentTrip();
    const plannerContainer = document.getElementById("planner-main-view");
    const tripSelect = document.getElementById("planner-trip-select");

    // Populate trip select options
    if (tripSelect) {
      tripSelect.innerHTML = PlannerModule.trips.map(t => `
        <option value="${t.id}" ${t.id === PlannerModule.currentTripId ? 'selected' : ''}>
          ${t.title} (${t.daysCount} Days)
        </option>
      `).join("");
    }

    if (!trip || !plannerContainer) return;

    const totalActCost = PlannerModule.calculateTotalActivitiesCost(trip);
    const dest = DESTINATIONS.find(d => d.id === trip.destinationId);
    const est = dest ? BudgetEngine.calculateTripCost({
      destinationId: dest.id,
      days: trip.daysCount,
      travelers: trip.travelers,
      travelStyle: trip.travelStyle,
      includeFlights: true
    }) : null;

    const projectedGrandTotal = est ? est.grandTotalUSD : totalActCost;
    const budgetCap = trip.budgetCapUSD || 2500;
    const budgetPct = Math.min(100, Math.round((projectedGrandTotal / budgetCap) * 100));

    plannerContainer.innerHTML = `
      <!-- Trip Overview Header Card -->
      <div class="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm mb-6">
        <div class="flex flex-wrap items-start justify-between gap-4 pb-4 border-b border-slate-100">
          <div>
            <div class="flex items-center gap-2 mb-1">
              <span class="bg-indigo-50 text-indigo-700 text-xs font-bold px-2.5 py-0.5 rounded-full">
                ${trip.daysCount} Days
              </span>
              <span class="text-xs text-slate-500 font-medium">
                ${trip.startDate} &rarr; ${trip.endDate}
              </span>
              <span class="text-xs bg-slate-100 text-slate-600 px-2 py-0.5 rounded-full font-semibold">
                ${trip.travelers} Traveler(s) &bull; ${trip.travelStyle.toUpperCase()}
              </span>
            </div>
            <h2 class="text-2xl font-black text-slate-900 leading-tight">${trip.title}</h2>
            <p class="text-xs text-slate-500 mt-0.5">Destination: <span class="font-semibold text-slate-700">${trip.destinationName}</span></p>
          </div>

          <div class="flex flex-wrap items-center gap-2">
            <button onclick="App.copyTripSummary()" class="inline-flex items-center gap-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold px-3 py-2 rounded-xl transition">
              <svg class="w-4 h-4 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 5H6a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2v-1M8 5a2 2 0 002 2h2a2 2 0 002-2M8 5a2 2 0 012-2h2a2 2 0 012 2m0 0h2a2 2 0 012 2v3m2 4H10m0 0l3-3m-3 3l3 3"></path></svg>
              <span>Copy Itinerary</span>
            </button>
            <button onclick="App.deleteCurrentTrip()" class="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-xl transition" title="Delete Trip">
              <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg>
            </button>
          </div>
        </div>

        <!-- Trip Budget Progress -->
        <div class="pt-4 grid sm:grid-cols-3 gap-4 items-center">
          <div>
            <span class="text-xs text-slate-500 block">Projected Total Trip Cost</span>
            <span class="text-xl font-extrabold text-slate-900">${BudgetEngine.formatCurrency(projectedGrandTotal)}</span>
            <span class="text-[11px] text-slate-400 block">(Activities: ${BudgetEngine.formatCurrency(totalActCost)})</span>
          </div>
          <div>
            <span class="text-xs text-slate-500 block">Target Budget Limit</span>
            <span class="text-xl font-extrabold text-indigo-600">${BudgetEngine.formatCurrency(budgetCap)}</span>
            <span class="text-[11px] text-slate-400 block">${BudgetEngine.formatCurrency(Math.max(0, budgetCap - projectedGrandTotal))} remaining</span>
          </div>
          <div>
            <div class="flex items-center justify-between text-xs mb-1">
              <span class="font-medium text-slate-600">Budget Consumed</span>
              <span class="font-bold ${budgetPct > 100 ? 'text-rose-600' : 'text-emerald-600'}">${budgetPct}%</span>
            </div>
            <div class="w-full bg-slate-100 rounded-full h-2.5 overflow-hidden">
              <div class="h-full rounded-full transition-all duration-500 ${budgetPct > 100 ? 'bg-rose-500' : 'bg-emerald-500'}" style="width: ${budgetPct}%"></div>
            </div>
          </div>
        </div>
      </div>

      <!-- Main Columns: Day-by-day Itinerary (Left) & Packing Checklist (Right) -->
      <div class="grid lg:grid-cols-12 gap-6">
        <!-- Day-by-Day Schedule (8 cols) -->
        <div class="lg:col-span-8 space-y-4">
          <div class="flex items-center justify-between">
            <h3 class="text-lg font-bold text-slate-900 flex items-center gap-2">
              <svg class="w-5 h-5 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"></path></svg>
              Daily Schedule & Experiences
            </h3>
          </div>

          <!-- Days List -->
          <div class="space-y-4">
            ${trip.days.map(day => `
              <div class="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm">
                <div class="flex items-center justify-between pb-3 border-b border-slate-100 mb-3">
                  <div class="flex items-center gap-2.5">
                    <span class="w-8 h-8 rounded-xl bg-indigo-600 text-white font-extrabold text-sm flex items-center justify-center shadow-sm">
                      ${day.dayNumber}
                    </span>
                    <div>
                      <h4 class="font-bold text-slate-900 text-sm leading-tight">${day.theme}</h4>
                      <span class="text-[11px] text-slate-400">${day.activities.length} activity item(s)</span>
                    </div>
                  </div>

                  <button onclick="App.openNewActivityModal(${day.dayNumber})" class="inline-flex items-center gap-1 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 text-xs font-semibold px-2.5 py-1.5 rounded-lg transition">
                    <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path></svg>
                    <span>Add Activity</span>
                  </button>
                </div>

                <!-- Activities within this day -->
                ${day.activities.length === 0 ? `
                  <div class="text-center py-4 bg-slate-50/70 rounded-xl border border-dashed border-slate-200 text-xs text-slate-400">
                    No scheduled items for this day yet. Click "+ Add Activity" to schedule morning sights, cafes, or walks!
                  </div>
                ` : `
                  <div class="space-y-2.5">
                    ${day.activities.map(act => `
                      <div class="flex items-start justify-between gap-3 p-3 rounded-xl bg-slate-50/80 hover:bg-slate-50 border border-slate-200/60 transition text-xs">
                        <div class="flex items-start gap-2.5">
                          <span class="mt-0.5 px-2 py-0.5 rounded font-bold text-[10px] uppercase tracking-wider ${
                            act.time === 'Morning' ? 'bg-amber-100 text-amber-800' :
                            act.time === 'Afternoon' ? 'bg-sky-100 text-sky-800' : 'bg-purple-100 text-purple-800'
                          }">
                            ${act.time}
                          </span>
                          <div>
                            <div class="flex items-center gap-2">
                              <span class="font-bold text-slate-900 text-sm">${act.title}</span>
                              <span class="text-[10px] text-slate-500 bg-white px-1.5 py-0.2 rounded border border-slate-200">${act.category}</span>
                            </div>
                            ${act.location ? `<p class="text-[11px] text-slate-500 mt-0.5">📍 ${act.location}</p>` : ''}
                            ${act.notes ? `<p class="text-[11px] text-slate-600 mt-0.5 italic">"${act.notes}"</p>` : ''}
                          </div>
                        </div>

                        <div class="flex items-center gap-2">
                          <span class="font-bold text-slate-800 text-sm">${BudgetEngine.formatCurrency(act.costUSD)}</span>
                          <button onclick="App.deleteActivity(${day.dayNumber}, '${act.id}')" class="text-slate-300 hover:text-rose-500 p-1 transition" title="Delete Activity">
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>
                          </button>
                        </div>
                      </div>
                    `).join("")}
                  </div>
                `}
              </div>
            `).join("")}
          </div>
        </div>

        <!-- Packing Checklist & Quick Notes (4 cols) -->
        <div class="lg:col-span-4 space-y-6">
          <div class="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm">
            <div class="flex items-center justify-between pb-3 border-b border-slate-100 mb-3">
              <div>
                <h4 class="font-bold text-slate-900 text-sm flex items-center gap-2">
                  <svg class="w-4 h-4 text-emerald-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                  Trip Packing Checklist
                </h4>
                <span class="text-[11px] text-slate-400">
                  ${trip.packingList.filter(p => p.done).length} of ${trip.packingList.length} packed
                </span>
              </div>
            </div>

            <!-- Add Packing Item Form -->
            <form onsubmit="event.preventDefault(); App.addPackingItem();" class="flex gap-2 mb-3">
              <input 
                type="text" 
                id="new-packing-input" 
                placeholder="Add gear, documents, clothes..." 
                class="flex-1 bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 text-xs focus:ring-2 focus:ring-indigo-500 outline-none"
              />
              <button type="submit" class="bg-indigo-600 text-white px-3 py-1.5 rounded-xl text-xs font-semibold hover:bg-indigo-700 transition">
                Add
              </button>
            </form>

            <!-- Packing list items -->
            <div class="space-y-1.5 max-h-80 overflow-y-auto pr-1">
              ${trip.packingList.map(item => `
                <div class="flex items-center justify-between p-2 rounded-lg hover:bg-slate-50 transition text-xs group">
                  <label class="flex items-center gap-2.5 cursor-pointer flex-1">
                    <input 
                      type="checkbox" 
                      ${item.done ? 'checked' : ''} 
                      onchange="App.togglePackingItem('${item.id}')"
                      class="w-4 h-4 text-indigo-600 rounded border-slate-300 focus:ring-indigo-500 cursor-pointer"
                    />
                    <span class="${item.done ? 'line-through text-slate-400' : 'text-slate-700 font-medium'}">
                      ${item.text}
                    </span>
                  </label>
                  <span class="text-[10px] text-slate-400 bg-slate-100 px-1.5 py-0.5 rounded">${item.category}</span>
                  <button onclick="App.deletePackingItem('${item.id}')" class="text-slate-300 hover:text-rose-500 opacity-0 group-hover:opacity-100 transition ml-1">
                    <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>
                  </button>
                </div>
              `).join("")}
            </div>
          </div>
        </div>
      </div>
    `;
  },

  onTripChange(tripId) {
    PlannerModule.currentTripId = tripId;
    this.renderPlanner();
  },

  deleteCurrentTrip() {
    const trip = PlannerModule.getCurrentTrip();
    if (!trip) return;
    if (confirm(`Are you sure you want to delete "${trip.title}"?`)) {
      PlannerModule.deleteTrip(trip.id);
      this.showToast("Trip deleted");
      this.renderPlanner();
    }
  },

  openNewTripModal() {
    const modal = document.getElementById("new-trip-modal");
    if (modal) {
      // Pre-fill destination selector with destinations
      const destSelect = document.getElementById("new-trip-dest");
      if (destSelect) {
        destSelect.innerHTML = DESTINATIONS.map(d => `
          <option value="${d.id}">${d.name}, ${d.country}</option>
        `).join("");
      }

      // Default start and end dates
      const startInput = document.getElementById("new-trip-start");
      const endInput = document.getElementById("new-trip-end");
      const today = new Date();
      const inTwoWeeks = new Date(today);
      inTwoWeeks.setDate(today.getDate() + 14);
      const inThreeWeeks = new Date(inTwoWeeks);
      inThreeWeeks.setDate(inTwoWeeks.getDate() + 7);

      if (startInput) startInput.value = inTwoWeeks.toISOString().split("T")[0];
      if (endInput) endInput.value = inThreeWeeks.toISOString().split("T")[0];

      modal.classList.remove("hidden");
    }
  },

  closeNewTripModal() {
    const modal = document.getElementById("new-trip-modal");
    if (modal) modal.classList.add("hidden");
  },

  handleCreateNewTrip(e) {
    e.preventDefault();
    const title = document.getElementById("new-trip-title")?.value;
    const destId = document.getElementById("new-trip-dest")?.value;
    const startDate = document.getElementById("new-trip-start")?.value;
    const endDate = document.getElementById("new-trip-end")?.value;
    const travelers = document.getElementById("new-trip-travelers")?.value;
    const travelStyle = document.getElementById("new-trip-style")?.value;
    const budgetCapUSD = document.getElementById("new-trip-budget")?.value;

    const dest = DESTINATIONS.find(d => d.id === destId);
    if (!dest) return;

    PlannerModule.createNewTrip({
      title: title || `${dest.name} Discovery Trip`,
      destinationId: dest.id,
      destinationName: `${dest.name}, ${dest.country}`,
      startDate,
      endDate,
      travelers,
      travelStyle,
      budgetCapUSD
    });

    this.closeNewTripModal();
    this.showToast("🎉 New trip created!");
    this.renderPlanner();
  },

  openNewActivityModal(dayNumber) {
    const modal = document.getElementById("new-activity-modal");
    const dayInput = document.getElementById("act-day-input");
    const dayDisplay = document.getElementById("act-day-display");
    if (!modal) return;

    if (dayInput) dayInput.value = dayNumber;
    if (dayDisplay) dayDisplay.textContent = `Day ${dayNumber}`;

    modal.classList.remove("hidden");
  },

  closeNewActivityModal() {
    const modal = document.getElementById("new-activity-modal");
    if (modal) modal.classList.add("hidden");
  },

  handleCreateActivity(e) {
    e.preventDefault();
    const trip = PlannerModule.getCurrentTrip();
    if (!trip) return;

    const dayNumber = parseInt(document.getElementById("act-day-input")?.value) || 1;
    const title = document.getElementById("act-title-input")?.value;
    const time = document.getElementById("act-time-select")?.value;
    const category = document.getElementById("act-cat-select")?.value;
    const location = document.getElementById("act-loc-input")?.value;
    const costUSD = document.getElementById("act-cost-input")?.value;
    const notes = document.getElementById("act-notes-input")?.value;

    if (!title) return;

    PlannerModule.addActivity(trip.id, dayNumber, {
      title,
      time,
      category,
      location,
      costUSD,
      notes
    });

    this.closeNewActivityModal();
    this.showToast("Activity added!");
    this.renderPlanner();
  },

  deleteActivity(dayNumber, actId) {
    const trip = PlannerModule.getCurrentTrip();
    if (!trip) return;
    PlannerModule.deleteActivity(trip.id, dayNumber, actId);
    this.showToast("Activity removed");
    this.renderPlanner();
  },

  togglePackingItem(itemId) {
    const trip = PlannerModule.getCurrentTrip();
    if (!trip) return;
    PlannerModule.togglePackingItem(trip.id, itemId);
    this.renderPlanner();
  },

  addPackingItem() {
    const trip = PlannerModule.getCurrentTrip();
    const input = document.getElementById("new-packing-input");
    if (!trip || !input || !input.value.trim()) return;

    PlannerModule.addPackingItem(trip.id, "Custom", input.value.trim());
    input.value = "";
    this.renderPlanner();
  },

  deletePackingItem(itemId) {
    const trip = PlannerModule.getCurrentTrip();
    if (!trip) return;
    PlannerModule.deletePackingItem(trip.id, itemId);
    this.renderPlanner();
  },

  copyTripSummary() {
    const trip = PlannerModule.getCurrentTrip();
    if (!trip) return;
    const text = PlannerModule.exportTripSummaryText(trip);
    navigator.clipboard.writeText(text).then(() => {
      this.showToast("📋 Full trip itinerary copied to clipboard!");
    }).catch(() => {
      this.showToast("Itinerary ready for export!");
    });
  },

  /* ==============================================================
     WISHLIST & VISITED VIEW
     ============================================================== */
  renderWishlistView() {
    const container = document.getElementById("wishlist-items-container");
    const statSaved = document.getElementById("wishlist-stat-saved");
    const statVisited = document.getElementById("wishlist-stat-visited");
    const statBudget = document.getElementById("wishlist-stat-budget");
    if (!container) return;

    const wishlistItems = WishlistModule.items.filter(i => i.status === "wishlist");
    const visitedItems = WishlistModule.items.filter(i => i.status === "visited");
    const projection = WishlistModule.calculateBucketListTotal("midRange", 7);

    if (statSaved) statSaved.textContent = wishlistItems.length;
    if (statVisited) statVisited.textContent = visitedItems.length;
    if (statBudget) statBudget.textContent = BudgetEngine.formatCurrency(projection.totalUSD);

    if (WishlistModule.items.length === 0) {
      container.innerHTML = `
        <div class="col-span-full py-16 text-center">
          <div class="w-16 h-16 mx-auto mb-4 bg-rose-50 text-rose-500 rounded-full flex items-center justify-center">
            <svg class="w-8 h-8 fill-current" viewBox="0 0 24 24"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg>
          </div>
          <h3 class="text-lg font-bold text-slate-800">Your travel wishlist is empty</h3>
          <p class="text-sm text-slate-500 max-w-md mx-auto mt-1 mb-4">Click the heart icon on any destination in the Destination Finder to save your dream adventures!</p>
          <button onclick="App.switchTab('finder')" class="inline-flex items-center gap-2 bg-indigo-600 text-white font-medium px-4 py-2 rounded-lg text-sm hover:bg-indigo-700 transition">
            Discover Destinations
          </button>
        </div>
      `;
      return;
    }

    container.innerHTML = WishlistModule.items.map(item => {
      const dest = DESTINATIONS.find(d => d.id === item.destId);
      if (!dest) return "";

      const isVisited = item.status === "visited";
      const costEst = BudgetEngine.calculateTripCost({
        destinationId: dest.id,
        days: 7,
        travelers: 1,
        travelStyle: "midRange",
        includeFlights: true
      });

      return `
        <div class="bg-white rounded-2xl overflow-hidden border border-slate-200 shadow-sm hover:shadow-md transition flex flex-col justify-between">
          <div>
            <!-- Header Image -->
            <div class="relative h-44 w-full overflow-hidden bg-slate-100 cursor-pointer" onclick="App.openDestinationModal('${dest.id}')">
              <img src="${dest.image}" alt="${dest.name}" class="w-full h-full object-cover" />
              <div class="absolute inset-0 bg-gradient-to-t from-black/75 via-transparent to-transparent"></div>

              <!-- Status Toggle Badge -->
              <span class="absolute top-3 left-3 text-xs font-bold px-2.5 py-1 rounded-full shadow ${
                isVisited ? 'bg-emerald-600 text-white' : 'bg-rose-600 text-white'
              }">
                ${isVisited ? '✓ Visited' : '❤️ Wishlist'}
              </span>

              <!-- Remove button -->
              <button 
                onclick="event.stopPropagation(); WishlistModule.removeItem('${dest.id}'); App.renderWishlistView(); App.renderWishlistCount(); App.showToast('Removed from wishlist');" 
                class="absolute top-3 right-3 w-8 h-8 rounded-full bg-black/40 hover:bg-black/70 text-white flex items-center justify-center transition"
                title="Remove"
              >
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>
              </button>

              <div class="absolute bottom-3 left-3 right-3 text-white">
                <span class="text-xs text-sky-200">${dest.country}</span>
                <h3 class="text-xl font-bold leading-tight">${dest.name}</h3>
              </div>
            </div>

            <!-- Card Body -->
            <div class="p-4 space-y-3 text-xs">
              <!-- Status / Priority Row -->
              <div class="flex items-center justify-between text-slate-500">
                <span>Priority: <strong class="text-slate-800">${item.priority || 'Dream Trip'}</strong></span>
                <span>Target: <strong class="text-indigo-600">${item.targetSeason || 'Someday'}</strong></span>
              </div>

              <!-- Notes -->
              ${item.personalNotes ? `
                <div class="bg-slate-50 p-2.5 rounded-xl border border-slate-100 text-slate-600 italic">
                  "${item.personalNotes}"
                </div>
              ` : `
                <p class="text-slate-400 italic">No personal notes added yet.</p>
              `}

              <!-- Cost Estimation -->
              <div class="flex items-center justify-between pt-2 border-t border-slate-100">
                <span class="text-slate-500">Est. 7-Day Journey:</span>
                <span class="font-extrabold text-slate-900 text-sm">
                  ${BudgetEngine.formatCurrency(costEst.grandTotalUSD)}
                </span>
              </div>
            </div>
          </div>

          <!-- Card Footer Actions -->
          <div class="p-4 pt-0 flex items-center gap-2">
            <button 
              onclick="WishlistModule.updateItem('${dest.id}', { status: '${isVisited ? "wishlist" : "visited"}' }); App.renderWishlistView();" 
              class="flex-1 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold py-2 rounded-xl transition text-center"
            >
              Mark as ${isVisited ? 'Wishlist' : 'Visited'}
            </button>
            <button 
              onclick="App.quickPlanTrip('${dest.id}')" 
              class="bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-semibold py-2 px-3 rounded-xl transition"
            >
              Plan Trip
            </button>
          </div>
        </div>
      `;
    }).join("");
  },

  /* ==============================================================
     TOAST NOTIFICATIONS
     ============================================================== */
  showToast(message) {
    const toast = document.getElementById("toast-notification");
    const toastMsg = document.getElementById("toast-message");
    if (!toast || !toastMsg) return;

    toastMsg.textContent = message;
    toast.classList.remove("translate-y-24", "opacity-0", "pointer-events-none");
    toast.classList.add("translate-y-0", "opacity-100");

    clearTimeout(this._toastTimeout);
    this._toastTimeout = setTimeout(() => {
      toast.classList.add("translate-y-24", "opacity-0", "pointer-events-none");
      toast.classList.remove("translate-y-0", "opacity-100");
    }, 3200);
  }
};

// Initialize App when DOM is ready
document.addEventListener("DOMContentLoaded", () => {
  App.init();
});
