/**
 * WanderPulse Destinations Database
 * Rich, comprehensive dataset of global destinations with geo-coordinates,
 * travel vibes, seasonal suitability, and tiered daily cost breakdowns.
 */

const DESTINATIONS = [
  {
    id: "kyoto-japan",
    name: "Kyoto",
    country: "Japan",
    continent: "Asia",
    tagline: "Ancient temples, serene zen gardens, and timeless culinary artistry",
    description: "Kyoto is the cultural heart of Japan, boasting thousands of classical Buddhist temples, imperial palaces, traditional wooden houses, and magical bamboo groves.",
    image: "https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?auto=format&fit=crop&w=1200&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1503899036084-c55cdd92da26?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1492571350019-22de08371fd3?auto=format&fit=crop&w=800&q=80"
    ],
    coordinates: [35.0116, 135.7681],
    vibes: ["Culture & History", "Foodie", "Romantic", "Photography"],
    bestSeasons: ["Spring", "Autumn"],
    budgetTier: "$$", // $, $$, $$$, $$$$
    baseFlightEstUSD: 850,
    dailyCostsUSD: {
      backpacker: { lodging: 35, food: 22, transport: 10, activities: 15 },
      midRange: { lodging: 110, food: 55, transport: 20, activities: 35 },
      luxury: { lodging: 380, food: 150, transport: 65, activities: 90 }
    },
    currency: "JPY",
    language: "Japanese",
    safetyRating: 4.9,
    highlights: ["Fushimi Inari-taisha Shrine", "Arashiyama Bamboo Grove", "Kinkaku-ji (Golden Pavilion)", "Gion Geisha District", "Nishiki Market food crawl"],
    localCuisine: ["Kaiseki dining", "Matcha soft serve", "Kyoto-style ramen", "Yudofu (tofu hotpot)"],
    localTips: "Buy an IC transit card (Suica/Pasmo) for seamless train and bus travel. Visit Fushimi Inari at dawn to beat the crowds."
  },
  {
    id: "bali-indonesia",
    name: "Bali & Nusa Islands",
    country: "Indonesia",
    continent: "Asia",
    tagline: "Tropical paradise of lush rice terraces, sacred temples, and surf beaches",
    description: "An island of spirituality and natural beauty, Bali offers everything from serene yoga retreats in Ubud to thrilling barrel waves in Uluwatu and volcanic sunrise treks.",
    image: "https://images.unsplash.com/photo-1537996194471-e657df975ab4?auto=format&fit=crop&w=1200&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1518548419970-58e3b4079ab2?auto=format&fit=crop&w=800&q=80",
      "https://images.unsplash.com/photo-1555400038-63f5ba517a47?auto=format&fit=crop&w=800&q=80"
    ],
    coordinates: [-8.3405, 115.0920],
    vibes: ["Tropical & Beach", "Budget-friendly", "Adventure", "Wellness"],
    bestSeasons: ["Spring", "Summer", "Autumn"],
    budgetTier: "$",
    baseFlightEstUSD: 750,
    dailyCostsUSD: {
      backpacker: { lodging: 18, food: 12, transport: 6, activities: 10 },
      midRange: { lodging: 65, food: 28, transport: 15, activities: 25 },
      luxury: { lodging: 240, food: 85, transport: 40, activities: 65 }
    },
    currency: "IDR",
    language: "Indonesian, Balinese",
    safetyRating: 4.6,
    highlights: ["Tegallalang Rice Terraces", "Uluwatu Sunset Temple & Kecak Dance", "Mount Batur Sunrise Hike", "Nusa Penida Kelingking Beach", "Canggu surf breaks"],
    localCuisine: ["Nasi Goreng", "Babi Guling", "Satay Lilit", "Fresh Young Coconut"],
    localTips: "Renting a scooter is cheap ($5/day) but only if you have an international permit and experience. Use Grab or Gojek for rides."
  },
  {
    id: "amalfi-italy",
    name: "Amalfi Coast & Positano",
    country: "Italy",
    continent: "Europe",
    tagline: "Dramatic cliffside villages, azure waters, and Mediterranean romance",
    description: "A 50-kilometer stretch of mountainous coastline featuring pastel-hued villages clinging to cliffs, fragrant lemon groves, and world-class coastal drives.",
    image: "https://images.unsplash.com/photo-1533105079780-92b9be482077?auto=format&fit=crop&w=1200&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1516483638261-f4dbaf036963?auto=format&fit=crop&w=800&q=80"
    ],
    coordinates: [40.6340, 14.6027],
    vibes: ["Romantic", "Luxury", "Foodie", "Photography"],
    bestSeasons: ["Spring", "Summer", "Autumn"],
    budgetTier: "$$$$",
    baseFlightEstUSD: 900,
    dailyCostsUSD: {
      backpacker: { lodging: 65, food: 35, transport: 18, activities: 20 },
      midRange: { lodging: 190, food: 80, transport: 35, activities: 45 },
      luxury: { lodging: 550, food: 220, transport: 110, activities: 140 }
    },
    currency: "EUR",
    language: "Italian",
    safetyRating: 4.8,
    highlights: ["Positano Beach & Cliff Views", "Path of the Gods hike", "Villa Cimbrone Gardens in Ravello", "Private boat charter to Capri", "Limoncello tasting"],
    localCuisine: ["Scialatielli ai frutti di mare", "Delizia al Limone", "Fresh buffalo mozzarella", "Neapolitan wood-fired pizza"],
    localTips: "Ferries between towns are much faster and offer better views than congested coastal buses."
  },
  {
    id: "banff-canada",
    name: "Banff & Lake Louise",
    country: "Canada",
    continent: "North America",
    tagline: "Turquoise glacial lakes, jagged Rockies peaks, and alpine wilderness",
    description: "Nestled in the Canadian Rocky Mountains, Banff National Park is legendary for its vibrant turquoise waters, snow-capped peaks, and abundant wildlife.",
    image: "https://images.unsplash.com/photo-1503614472-8c93d56e92ce?auto=format&fit=crop&w=1200&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?auto=format&fit=crop&w=800&q=80"
    ],
    coordinates: [51.1784, -115.5708],
    vibes: ["Mountain & Hiking", "Adventure", "Photography", "Wellness"],
    bestSeasons: ["Summer", "Winter"],
    budgetTier: "$$$",
    baseFlightEstUSD: 550,
    dailyCostsUSD: {
      backpacker: { lodging: 45, food: 30, transport: 25, activities: 25 },
      midRange: { lodging: 160, food: 65, transport: 45, activities: 55 },
      luxury: { lodging: 450, food: 160, transport: 90, activities: 120 }
    },
    currency: "CAD",
    language: "English",
    safetyRating: 4.9,
    highlights: ["Canoeing on Moraine Lake", "Lake Louise lakeshore stroll", "Icefields Parkway scenic drive", "Banff Upper Hot Springs", "Sulphur Mountain Gondola"],
    localCuisine: ["Alberta AAA Prime Rib", "Warm poutine", "Bannock bread", "Craft microbrews"],
    localTips: "Book Lake Louise and Moraine Lake park shuttles months in advance as private vehicular access is restricted."
  },
  {
    id: "cape-town-south-africa",
    name: "Cape Town",
    country: "South Africa",
    continent: "Africa",
    tagline: "Where dramatic Table Mountain meets two oceans and vibrant vineyards",
    description: "Cape Town blends breathtaking natural landscapes, coastal penguin colonies, renowned wineries in Stellenbosch, and rich cosmopolitan culture at remarkable value.",
    image: "https://images.unsplash.com/photo-1580618672591-eb180b1a973f?auto=format&fit=crop&w=1200&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=800&q=80"
    ],
    coordinates: [-33.9249, 18.4241],
    vibes: ["Adventure", "Foodie", "Budget-friendly", "Tropical & Beach"],
    bestSeasons: ["Spring", "Summer", "Autumn"],
    budgetTier: "$$",
    baseFlightEstUSD: 1100,
    dailyCostsUSD: {
      backpacker: { lodging: 28, food: 20, transport: 12, activities: 18 },
      midRange: { lodging: 85, food: 40, transport: 22, activities: 35 },
      luxury: { lodging: 290, food: 110, transport: 60, activities: 85 }
    },
    currency: "ZAR",
    language: "English, Afrikaans, Xhosa",
    safetyRating: 4.2,
    highlights: ["Table Mountain cable car or hike", "Boulders Beach penguin colony", "Cape Point scenic drive", "Franschhoek Wine Tram", "Kirstenbosch Botanical Gardens"],
    localCuisine: ["Braai BBQ", "Bobotie casserole", "Cape Malay curry", "Pinotage wines"],
    localTips: "Uber is extremely safe, reliable, and affordable for getting around Cape Town."
  },
  {
    id: "reykjavik-iceland",
    name: "Reykjavik & The Golden Circle",
    country: "Iceland",
    continent: "Europe",
    tagline: "Land of fire and ice, roaring waterfalls, and dancing Northern Lights",
    description: "Iceland's surreal geothermal landscapes feature active volcanoes, cascading waterfalls, black sand beaches, and steaming geothermal lagoons under the Aurora Borealis.",
    image: "https://images.unsplash.com/photo-1504893524553-b855bce32c67?auto=format&fit=crop&w=1200&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1529963183134-61a90db47eaf?auto=format&fit=crop&w=800&q=80"
    ],
    coordinates: [64.1466, -21.9426],
    vibes: ["Adventure", "Photography", "Mountain & Hiking", "Wellness"],
    bestSeasons: ["Winter", "Summer", "Autumn"],
    budgetTier: "$$$$",
    baseFlightEstUSD: 650,
    dailyCostsUSD: {
      backpacker: { lodging: 55, food: 35, transport: 35, activities: 30 },
      midRange: { lodging: 180, food: 75, transport: 60, activities: 65 },
      luxury: { lodging: 490, food: 190, transport: 130, activities: 150 }
    },
    currency: "ISK",
    language: "Icelandic, English",
    safetyRating: 4.9,
    highlights: ["Blue Lagoon & Sky Lagoon thermal soak", "Gullfoss Waterfall & Geysir", "Reynisfjara Black Sand Beach", "Chasing Northern Lights", "Jökulsárlón Glacier Lagoon"],
    localCuisine: ["Icelandic lamb stew (Kjötsúpa)", "Fresh Arctic char", "Rúgbrauð rye bread", "Skyr with wild berries"],
    localTips: "Renting a 4x4 campervan is one of the most cost-effective and adventurous ways to experience the Ring Road."
  },
  {
    id: "cusco-peru",
    name: "Cusco & Machu Picchu",
    country: "Peru",
    continent: "South America",
    tagline: "The mystical Inca empire, high Andes passes, and Rainbow Mountain",
    description: "High in the Peruvian Andes, Cusco was the historic capital of the Inca Empire. Today it serves as the gateway to the sacred citadel of Machu Picchu.",
    image: "https://images.unsplash.com/photo-1526392060635-9d6019884377?auto=format&fit=crop&w=1200&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1589802829985-817e51171b92?auto=format&fit=crop&w=800&q=80"
    ],
    coordinates: [-13.5319, -71.9675],
    vibes: ["Culture & History", "Mountain & Hiking", "Adventure", "Budget-friendly"],
    bestSeasons: ["Spring", "Summer", "Autumn"],
    budgetTier: "$",
    baseFlightEstUSD: 800,
    dailyCostsUSD: {
      backpacker: { lodging: 20, food: 14, transport: 8, activities: 20 },
      midRange: { lodging: 70, food: 32, transport: 20, activities: 45 },
      luxury: { lodging: 260, food: 95, transport: 65, activities: 110 }
    },
    currency: "PEN",
    language: "Spanish, Quechua",
    safetyRating: 4.5,
    highlights: ["Machu Picchu sunrise visit", "Inca Trail or Salkantay Trek", "Sacred Valley of the Incas", "Rainbow Mountain (Vinicunca)", "San Pedro Market"],
    localCuisine: ["Ceviche clásico", "Lomo Saltado", "Causa Rellena", "Coca tea for altitude"],
    localTips: "Spend the first 24-48 hours resting and hydrating with coca tea to acclimatize to Cusco's 3,400m altitude before trekking."
  },
  {
    id: "swiss-alps-zermatt",
    name: "Zermatt & Swiss Alps",
    country: "Switzerland",
    continent: "Europe",
    tagline: "The majestic Matterhorn, world-class skiing, and panoramic alpine trains",
    description: "A car-free fairytale village sitting at the foot of the pyramid-shaped Matterhorn, renowned for alpine mountaineering, pristine cogwheel railways, and fondue chalets.",
    image: "https://images.unsplash.com/photo-1530122037265-a5f1f91d3b99?auto=format&fit=crop&w=1200&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1502784444187-359ac186c5bb?auto=format&fit=crop&w=800&q=80"
    ],
    coordinates: [45.9765, 7.7491],
    vibes: ["Mountain & Hiking", "Luxury", "Photography", "Adventure"],
    bestSeasons: ["Winter", "Summer"],
    budgetTier: "$$$$",
    baseFlightEstUSD: 900,
    dailyCostsUSD: {
      backpacker: { lodging: 70, food: 40, transport: 35, activities: 35 },
      midRange: { lodging: 210, food: 85, transport: 55, activities: 70 },
      luxury: { lodging: 600, food: 240, transport: 120, activities: 160 }
    },
    currency: "CHF",
    language: "German, French, English",
    safetyRating: 4.9,
    highlights: ["Gornergrat cogwheel train with Matterhorn reflection", "Glacier Paradise cable car", "5 Lakes Walk (5-Seenweg)", "Glacier Express train ride", "Matterhorn Museum"],
    localCuisine: ["Swiss cheese fondue", "Crispy Rösti", "Raclette", "Swiss artisan chocolates"],
    localTips: "Get a Swiss Travel Pass if you plan on riding scenic railways across the country; it covers trains, boats, and city transit."
  },
  {
    id: "santorini-greece",
    name: "Santorini (Thira)",
    country: "Greece",
    continent: "Europe",
    tagline: "Whitewashed caldera cliffs, deep blue domes, and legendary sunsets",
    description: "Formed by an ancient volcanic eruption, Santorini features breathtaking cliffside villages overlooking a deep sea caldera, volcanic beaches, and sublime Greek tavernas.",
    image: "https://images.unsplash.com/photo-1570077188670-e3a8d69ac5ff?auto=format&fit=crop&w=1200&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?auto=format&fit=crop&w=800&q=80"
    ],
    coordinates: [36.3932, 25.4615],
    vibes: ["Romantic", "Photography", "Tropical & Beach", "Foodie"],
    bestSeasons: ["Spring", "Summer", "Autumn"],
    budgetTier: "$$$",
    baseFlightEstUSD: 850,
    dailyCostsUSD: {
      backpacker: { lodging: 45, food: 28, transport: 15, activities: 20 },
      midRange: { lodging: 160, food: 65, transport: 30, activities: 45 },
      luxury: { lodging: 480, food: 180, transport: 80, activities: 120 }
    },
    currency: "EUR",
    language: "Greek, English",
    safetyRating: 4.8,
    highlights: ["Oia Sunset viewing point", "Fira to Oia caldera cliffside hike", "Catamaran sunset sailing cruise", "Red Beach & Akrotiri ruins", "Santo Wines cliff winery"],
    localCuisine: ["Fresh Greek salad with Feta", "Tomatokeftedes (tomato fritters)", "Grilled octopus", "Assyrtiko white wine"],
    localTips: "Visit in shoulder months (May or September-October) for pleasant weather, fewer crowds, and 40% cheaper lodging."
  },
  {
    id: "queenstown-new-zealand",
    name: "Queenstown & Milford Sound",
    country: "New Zealand",
    continent: "Oceania",
    tagline: "The adventure capital of the world surrounded by the Southern Alps",
    description: "Nestled on the shores of crystal Lake Wakatipu, Queenstown is the global home of bungee jumping, jet boating, scenic fiords, and epic mountain hikes.",
    image: "https://images.unsplash.com/photo-1589871973318-9ca1258faa5d?auto=format&fit=crop&w=1200&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1507699622108-4be3abd695ad?auto=format&fit=crop&w=800&q=80"
    ],
    coordinates: [-45.0312, 168.6626],
    vibes: ["Adventure", "Mountain & Hiking", "Photography", "Romantic"],
    bestSeasons: ["Summer", "Autumn", "Winter", "Spring"],
    budgetTier: "$$$",
    baseFlightEstUSD: 1200,
    dailyCostsUSD: {
      backpacker: { lodging: 40, food: 28, transport: 20, activities: 35 },
      midRange: { lodging: 140, food: 60, transport: 40, activities: 75 },
      luxury: { lodging: 420, food: 170, transport: 95, activities: 180 }
    },
    currency: "NZD",
    language: "English, Māori",
    safetyRating: 4.9,
    highlights: ["Milford Sound scenic fiord cruise", "Skyline Gondola & Luge tracks", "AJ Hackett Kawarau Bridge Bungee", "TSS Earnslaw vintage steamship", "Routeburn Track day hike"],
    localCuisine: ["Famous Fergburger", "Central Otago Pinot Noir", "New Zealand green-lipped mussels", "Pavlova meringue"],
    localTips: "Book Milford Sound tours that depart early in the morning from Queenstown to avoid convoy traffic on the Milford Road."
  },
  {
    id: "marrakech-morocco",
    name: "Marrakech & Sahara Gate",
    country: "Morocco",
    continent: "Africa",
    tagline: "Vibrant souks, Moorish palaces, fragrant spices, and desert dreams",
    description: "An intoxicating sensory journey through winding medinas, mosaic-filled riads, snake charmers in Jemaa el-Fnaa, and access to the majestic dunes of the Sahara.",
    image: "https://images.unsplash.com/photo-1539020140153-e479b8c22e70?auto=format&fit=crop&w=1200&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1548013146-72479768bada?auto=format&fit=crop&w=800&q=80"
    ],
    coordinates: [31.6295, -7.9811],
    vibes: ["Culture & History", "Foodie", "Budget-friendly", "Photography"],
    bestSeasons: ["Spring", "Autumn", "Winter"],
    budgetTier: "$",
    baseFlightEstUSD: 750,
    dailyCostsUSD: {
      backpacker: { lodging: 20, food: 12, transport: 6, activities: 14 },
      midRange: { lodging: 70, food: 30, transport: 16, activities: 30 },
      luxury: { lodging: 280, food: 95, transport: 50, activities: 80 }
    },
    currency: "MAD",
    language: "Arabic, Berber, French",
    safetyRating: 4.4,
    highlights: ["Jemaa el-Fnaa night market", "Jardin Majorelle & YSL Museum", "Bahia Palace mosaics", "Souk shopping for lanterns & rugs", "Overnight luxury Sahara glamping"],
    localCuisine: ["Slow-cooked Lamb Tagine", "Fluffy Couscous royale", "Pastilla savory-sweet pie", "Moroccan mint tea ceremony"],
    localTips: "Stay in a traditional riad inside the Medina rather than a Western hotel for the authentic architectural and hospitality experience."
  },
  {
    id: "oaxaca-mexico",
    name: "Oaxaca City",
    country: "Mexico",
    continent: "North America",
    tagline: "The gastronomic capital of Mexico, indigenous art, and mezcal distilleries",
    description: "Oaxaca is world-renowned for its culinary depth, indigenous artisan textiles, colorful colonial streets, ancient Zapotec ruins, and smoky mezcal traditions.",
    image: "https://images.unsplash.com/photo-1512813195386-6cf811ad3542?auto=format&fit=crop&w=1200&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1568402102990-bc541580b59f?auto=format&fit=crop&w=800&q=80"
    ],
    coordinates: [17.0732, -96.7266],
    vibes: ["Foodie", "Culture & History", "Budget-friendly", "Photography"],
    bestSeasons: ["Autumn", "Winter", "Spring"],
    budgetTier: "$",
    baseFlightEstUSD: 600,
    dailyCostsUSD: {
      backpacker: { lodging: 22, food: 14, transport: 6, activities: 12 },
      midRange: { lodging: 75, food: 35, transport: 15, activities: 25 },
      luxury: { lodging: 250, food: 100, transport: 45, activities: 65 }
    },
    currency: "MXN",
    language: "Spanish, Zapotec",
    safetyRating: 4.6,
    highlights: ["Monte Albán archeological hilltop", "Hierve el Agua petrified waterfalls", "Tlacolula Sunday market", "Artisanal Mezcal tasting palenques", "Santo Domingo Church"],
    localCuisine: ["Seven distinct Moles (Negro, Coloradito, etc.)", "Tlayudas (Oaxacan pizzas)", "Quesillo string cheese", "Chapulines (toasted grasshoppers)"],
    localTips: "Visit the 20 de Noviembre market and walk through the 'Pasillo de Humo' (Smoke Alley) for fresh grilled meats."
  },
  {
    id: "tromso-norway",
    name: "Tromsø & The Arctic Fjords",
    country: "Norway",
    continent: "Europe",
    tagline: "Gateway to the Arctic, whale watching, dog sledding, and aurora borealis",
    description: "Located 350 km north of the Arctic Circle, Tromsø is a vibrant island city where you can chase the Aurora Borealis, sail with orcas, and experience polar nights or midnight sun.",
    image: "https://images.unsplash.com/photo-1517411032315-54ef2cb783bb?auto=format&fit=crop&w=1200&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1531366936337-7c912a4589a7?auto=format&fit=crop&w=800&q=80"
    ],
    coordinates: [69.6492, 18.9553],
    vibes: ["Adventure", "Photography", "Wellness", "Mountain & Hiking"],
    bestSeasons: ["Winter", "Autumn"],
    budgetTier: "$$$$",
    baseFlightEstUSD: 850,
    dailyCostsUSD: {
      backpacker: { lodging: 60, food: 35, transport: 25, activities: 45 },
      midRange: { lodging: 175, food: 80, transport: 45, activities: 85 },
      luxury: { lodging: 460, food: 210, transport: 110, activities: 190 }
    },
    currency: "NOK",
    language: "Norwegian, English",
    safetyRating: 4.9,
    highlights: ["Aurora chase by minibus or catamaran", "Husky dog sledding across snow valleys", "Whale watching fjord safaris", "Fjellheisen cable car panoramic viewpoint", "Sámi reindeer camp and culture"],
    localCuisine: ["Fresh Norwegian cod & salmon", "Reindeer stew (Finnbiff)", "Brunost brown goat cheese", "Cloudberry preserves"],
    localTips: "Bring layers of merino wool! Winter temperatures hover around -4°C to -10°C, but thermal undergarments make outdoor chasing comfortable."
  },
  {
    id: "bangkok-thailand",
    name: "Bangkok & Ayutthaya",
    country: "Thailand",
    continent: "Asia",
    tagline: "Golden stupas, electrifying street food, canal longtails, and rooftop vibes",
    description: "Bangkok seamlessly marries centuries-old Buddhist heritage and ornate riverside palaces with a hyper-modern metropolis known for Michelin-starred street stalls and floating markets.",
    image: "https://images.unsplash.com/photo-1508009603885-50cf7c579365?auto=format&fit=crop&w=1200&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1563492065599-3520f775eeed?auto=format&fit=crop&w=800&q=80"
    ],
    coordinates: [13.7563, 100.5018],
    vibes: ["Foodie", "Culture & History", "Budget-friendly", "Nightlife"],
    bestSeasons: ["Winter", "Spring"],
    budgetTier: "$",
    baseFlightEstUSD: 700,
    dailyCostsUSD: {
      backpacker: { lodging: 18, food: 12, transport: 6, activities: 10 },
      midRange: { lodging: 65, food: 30, transport: 14, activities: 22 },
      luxury: { lodging: 240, food: 90, transport: 40, activities: 65 }
    },
    currency: "THB",
    language: "Thai, English widely spoken in tourist zones",
    safetyRating: 4.5,
    highlights: ["Grand Palace & Wat Phra Kaew", "Wat Arun (Temple of Dawn)", "Chao Phraya River express boat", "Chatuchak Weekend Market", "Day trip to Ayutthaya temple ruins"],
    localCuisine: ["Pad Thai with giant river prawns", "Tom Yum Goong", "Mango Sticky Rice", "Som Tum green papaya salad"],
    localTips: "Ride the MRT subway and BTS Skytrain to avoid notorious Bangkok street traffic during peak hours."
  },
  {
    id: "lisbon-portugal",
    name: "Lisbon & Sintra",
    country: "Portugal",
    continent: "Europe",
    tagline: "Pastel hills, vintage yellow trams, melancholic Fado, and custard tarts",
    description: "Sun-drenched Lisbon charms visitors with tile-lined façades, scenic miradouros (viewpoints), vibrant culinary scenes, and nearby whimsical fairytale palaces in Sintra.",
    image: "https://images.unsplash.com/photo-1509840841025-9088ba78a826?auto=format&fit=crop&w=1200&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1588614959060-4d144f28b207?auto=format&fit=crop&w=800&q=80"
    ],
    coordinates: [38.7223, -9.1393],
    vibes: ["Culture & History", "Foodie", "Romantic", "Budget-friendly"],
    bestSeasons: ["Spring", "Summer", "Autumn"],
    budgetTier: "$$",
    baseFlightEstUSD: 650,
    dailyCostsUSD: {
      backpacker: { lodging: 32, food: 22, transport: 10, activities: 15 },
      midRange: { lodging: 110, food: 48, transport: 20, activities: 30 },
      luxury: { lodging: 340, food: 130, transport: 55, activities: 80 }
    },
    currency: "EUR",
    language: "Portuguese, English",
    safetyRating: 4.8,
    highlights: ["Historic Tram 28 through Alfama", "Pena Palace & Quinta da Regaleira in Sintra", "Belém Tower & Jerónimos Monastery", "Miradouro de Santa Luzia sunset", "Live Fado in Bairro Alto"],
    localCuisine: ["Pastéis de Belém custard tarts", "Bacalhau à Brás (salted cod)", "Polvo à Lagareiro (roasted octopus)", "Ginjinha cherry liqueur"],
    localTips: "Wear comfortable shoes with grip! Lisbon's charming limestone cobblestone hills (calçada) can be slippery."
  },
  {
    id: "tokyo-japan",
    name: "Tokyo",
    country: "Japan",
    continent: "Asia",
    tagline: "Futuristic neon metropolises, tranquil shrines, and world-leading gastronomy",
    description: "Tokyo is a dynamic juxtaposition of towering high-tech skyscrapers, robotic cafes, historic Asakusa temples, and more Michelin stars than any other city on Earth.",
    image: "https://images.unsplash.com/photo-1503899036084-c55cdd92da26?auto=format&fit=crop&w=1200&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1542051841857-5f90071e7989?auto=format&fit=crop&w=800&q=80"
    ],
    coordinates: [35.6762, 139.6503],
    vibes: ["Culture & History", "Foodie", "Adventure", "Nightlife"],
    bestSeasons: ["Spring", "Autumn", "Winter"],
    budgetTier: "$$$",
    baseFlightEstUSD: 850,
    dailyCostsUSD: {
      backpacker: { lodging: 38, food: 25, transport: 12, activities: 18 },
      midRange: { lodging: 130, food: 60, transport: 22, activities: 40 },
      luxury: { lodging: 440, food: 180, transport: 75, activities: 110 }
    },
    currency: "JPY",
    language: "Japanese, English in transit/hotels",
    safetyRating: 5.0,
    highlights: ["Shibuya Crossing & Hachiko statue", "teamLab Planets immersive digital art", "Senso-ji temple in Asakusa", "Shinjuku Golden Gai alley bars", "Akihabara electronics & anime district"],
    localCuisine: ["Tonkotsu ramen", "Tsukiji sushi & sashimi", "Wagyu beef yakiniku", "Takoyaki octopus balls"],
    localTips: "7-Eleven and Lawson convenience stores (konbini) offer delicious, fresh bento boxes and onigiri for under $5."
  },
  {
    id: "maui-hawaii",
    name: "Maui (Hawaii)",
    country: "United States",
    continent: "North America",
    tagline: "Golden beaches, Road to Hana waterfalls, and volcanic Haleakalā sunsets",
    description: "The Valley Isle offers world-class beaches, sacred Hawaiian culture, volcanic crater sunrises, humpback whale sanctuaries, and lush rainforest drives.",
    image: "https://images.unsplash.com/photo-1542259009477-d625272157b7?auto=format&fit=crop&w=1200&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=800&q=80"
    ],
    coordinates: [20.7984, -156.3319],
    vibes: ["Tropical & Beach", "Romantic", "Adventure", "Luxury"],
    bestSeasons: ["Winter", "Spring", "Summer", "Autumn"],
    budgetTier: "$$$$",
    baseFlightEstUSD: 600,
    dailyCostsUSD: {
      backpacker: { lodging: 65, food: 35, transport: 35, activities: 25 },
      midRange: { lodging: 220, food: 85, transport: 65, activities: 65 },
      luxury: { lodging: 650, food: 220, transport: 120, activities: 160 }
    },
    currency: "USD",
    language: "English, Hawaiian",
    safetyRating: 4.8,
    highlights: ["Scenic Road to Hana day drive", "Haleakalā National Park summit sunrise", "Snorkeling at Molokini Crater", "Wailea & Ka'anapali beaches", "Authentic Hawaiian Luau"],
    localCuisine: ["Fresh Ahi Tuna Poke", "Kalua pork", "Loco Moco", "Shave Ice with Haupia foam"],
    localTips: "Reserve a sunrise vehicle pass for Haleakalā up to 60 days in advance on recreation.gov."
  },
  {
    id: "patagonia-chile",
    name: "Patagonia & Torres del Paine",
    country: "Chile",
    continent: "South America",
    tagline: "Granite spires, turquoise calving glaciers, and untamed winds of the south",
    description: "At the southern tip of the Americas lies one of the planet's wildest frontiers, characterized by azure lakes, hanging glaciers, and the towering granite horns of Torres del Paine.",
    image: "https://images.unsplash.com/photo-1527004013197-933c4bb611b3?auto=format&fit=crop&w=1200&q=80",
    gallery: [
      "https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?auto=format&fit=crop&w=800&q=80"
    ],
    coordinates: [-51.2532, -72.8814],
    vibes: ["Mountain & Hiking", "Adventure", "Photography"],
    bestSeasons: ["Summer", "Autumn", "Spring"],
    budgetTier: "$$$",
    baseFlightEstUSD: 1100,
    dailyCostsUSD: {
      backpacker: { lodging: 40, food: 25, transport: 25, activities: 35 },
      midRange: { lodging: 140, food: 55, transport: 45, activities: 65 },
      luxury: { lodging: 450, food: 160, transport: 100, activities: 140 }
    },
    currency: "CLP",
    language: "Spanish, English in lodges",
    safetyRating: 4.7,
    highlights: ["W-Trek or O-Circuit in Torres del Paine", "Grey Glacier boat or kayak tour", "Mirador Las Torres sunrise view", "Guanaco wildlife spotting", "French Valley lookout"],
    localCuisine: ["Cordero al palo (roasted Patagonian lamb)", "Centolla King Crab", "Calafate berry pies", "Chilean Carménère wine"],
    localTips: "Weather changes rapidly through all four seasons in a single hour; high-quality wind- and water-proof layers are essential."
  }
];

// Available Filter Dimensions
const FILTER_OPTIONS = {
  continents: ["All", "Asia", "Europe", "North America", "South America", "Africa", "Oceania"],
  vibes: ["All", "Adventure", "Culture & History", "Foodie", "Romantic", "Tropical & Beach", "Mountain & Hiking", "Budget-friendly", "Luxury", "Photography", "Wellness"],
  seasons: ["All", "Spring", "Summer", "Autumn", "Winter"],
  budgetTiers: ["All", "$", "$$", "$$$", "$$$$"]
};

// Global Currency Exchange Rates relative to USD
const CURRENCIES = {
  USD: { symbol: "$", rate: 1.0, name: "US Dollar" },
  EUR: { symbol: "€", rate: 0.92, name: "Euro" },
  GBP: { symbol: "£", rate: 0.79, name: "British Pound" },
  CAD: { symbol: "CA$", rate: 1.36, name: "Canadian Dollar" },
  AUD: { symbol: "A$", rate: 1.52, name: "Australian Dollar" },
  JPY: { symbol: "¥", rate: 155.0, name: "Japanese Yen" },
  IDR: { symbol: "Rp", rate: 16200.0, name: "Indonesian Rupiah" }
};
