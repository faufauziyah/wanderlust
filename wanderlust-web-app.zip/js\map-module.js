/**
 * WanderPulse Interactive Explore Map Module
 * Powered by Leaflet.js with custom modern pin markers, popups, and dynamic filtering.
 */

const MapModule = {
  mapInstance: null,
  markersLayer: null,
  destinations: [],
  selectedContinent: "All",
  selectedBudgetTier: "All",
  selectedVibe: "All",

  init(destinations) {
    this.destinations = destinations;
    const mapContainer = document.getElementById("leaflet-map");
    if (!mapContainer) return;

    // Check if Leaflet L object is loaded
    if (typeof L === "undefined") {
      console.warn("Leaflet library not loaded yet; map will initialize once available.");
      mapContainer.innerHTML = `
        <div class="flex flex-col items-center justify-center h-full text-center p-6 text-slate-500">
          <div class="w-12 h-12 mb-3 rounded-full bg-indigo-50 flex items-center justify-center text-indigo-600">
            <svg class="w-6 h-6 animate-spin" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z"></path></svg>
          </div>
          <p class="font-medium text-slate-700">Connecting to global map service...</p>
          <p class="text-xs text-slate-400 mt-1">If offline, you can still explore all destinations in the Finder tab!</p>
        </div>
      `;
      return;
    }

    try {
      // Create map centered on global view
      this.mapInstance = L.map("leaflet-map", {
        center: [20.0, 10.0],
        zoom: 2.3,
        minZoom: 2,
        maxZoom: 15,
        worldCopyJump: true,
        zoomControl: false
      });

      // Add Zoom Control to bottom right
      L.control.zoom({ position: "bottomright" }).addTo(this.mapInstance);

      // Clean, modern map tiles: CartoDB Positron / Voyager or OpenStreetMap
      L.tileLayer("https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png", {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>',
        subdomains: "abcd",
        maxZoom: 19
      }).addTo(this.mapInstance);

      this.markersLayer = L.layerGroup().addTo(this.mapInstance);
      this.renderMarkers();
    } catch (err) {
      console.error("Error initializing Leaflet map:", err);
    }
  },

  renderMarkers() {
    if (!this.mapInstance || !this.markersLayer) return;

    this.markersLayer.clearLayers();

    const filtered = this.destinations.filter(dest => {
      const matchContinent = this.selectedContinent === "All" || dest.continent === this.selectedContinent;
      const matchBudget = this.selectedBudgetTier === "All" || dest.budgetTier === this.selectedBudgetTier;
      const matchVibe = this.selectedVibe === "All" || dest.vibes.includes(this.selectedVibe);
      return matchContinent && matchBudget && matchVibe;
    });

    const bounds = [];

    filtered.forEach(dest => {
      const [lat, lng] = dest.coordinates;
      bounds.push([lat, lng]);

      // Custom HTML Marker Pin
      const customIcon = L.divIcon({
        className: "custom-map-pin-container",
        html: `
          <div class="group relative flex items-center justify-center cursor-pointer transition-transform duration-200 hover:scale-125">
            <div class="w-8 h-8 rounded-full bg-gradient-to-tr from-indigo-600 to-sky-500 text-white flex items-center justify-center shadow-lg border-2 border-white text-xs font-bold ring-2 ring-indigo-200">
              ${dest.budgetTier}
            </div>
            <div class="absolute -bottom-1 w-2 h-2 bg-indigo-600 rotate-45 transform"></div>
          </div>
        `,
        iconSize: [32, 36],
        iconAnchor: [16, 36],
        popupAnchor: [0, -32]
      });

      const marker = L.marker([lat, lng], { icon: customIcon });

      // Rich popup content
      const popupHtml = `
        <div class="map-popup-card font-sans text-slate-800 p-1" style="min-width: 240px; max-width: 280px;">
          <div class="relative h-28 w-full rounded-t-lg overflow-hidden mb-2">
            <img src="${dest.image}" alt="${dest.name}" class="w-full h-full object-cover" />
            <span class="absolute top-2 right-2 bg-black/60 backdrop-blur-sm text-white text-[10px] font-semibold px-2 py-0.5 rounded-full">
              ${dest.continent}
            </span>
            <span class="absolute bottom-2 left-2 bg-emerald-500 text-white text-[10px] font-bold px-2 py-0.5 rounded shadow">
              From $${dest.dailyCostsUSD.backpacker.lodging + dest.dailyCostsUSD.backpacker.food}/day
            </span>
          </div>
          <h4 class="font-bold text-base leading-tight text-slate-900">${dest.name}</h4>
          <p class="text-xs text-slate-500 mb-2">${dest.country} &bull; ${dest.vibes.slice(0, 2).join(", ")}</p>
          <p class="text-xs text-slate-600 line-clamp-2 mb-3">${dest.tagline}</p>
          <div class="flex items-center gap-1.5 pt-1 border-t border-slate-100">
            <button onclick="App.openDestinationModal('${dest.id}')" class="flex-1 text-center bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-medium py-1.5 px-2 rounded-md transition shadow-sm">
              Explore
            </button>
            <button onclick="App.quickPlanTrip('${dest.id}')" class="text-center bg-sky-50 hover:bg-sky-100 text-sky-700 text-xs font-medium py-1.5 px-2.5 rounded-md transition">
              Plan
            </button>
            <button onclick="App.toggleWishlist('${dest.id}')" class="p-1.5 text-slate-400 hover:text-rose-500 rounded-md hover:bg-rose-50 transition" title="Save to Wishlist">
              <svg class="w-4 h-4 fill-current" viewBox="0 0 24 24"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg>
            </button>
          </div>
        </div>
      `;

      marker.bindPopup(popupHtml, { className: "custom-leaflet-popup" });
      this.markersLayer.addLayer(marker);
    });

    // Update markers count badge
    const badge = document.getElementById("map-destinations-count");
    if (badge) {
      badge.textContent = `${filtered.length} destinations shown`;
    }
  },

  flyToDestination(destId) {
    const dest = this.destinations.find(d => d.id === destId);
    if (!dest || !this.mapInstance) return;

    this.mapInstance.flyTo(dest.coordinates, 8, {
      duration: 1.5,
      easeLinearity: 0.25
    });

    // Open popup after fly animation
    setTimeout(() => {
      this.markersLayer.eachLayer(layer => {
        const latLng = layer.getLatLng();
        if (latLng.lat === dest.coordinates[0] && latLng.lng === dest.coordinates[1]) {
          layer.openPopup();
        }
      });
    }, 1600);
  },

  setFilter(dimension, value) {
    if (dimension === "continent") this.selectedContinent = value;
    if (dimension === "budget") this.selectedBudgetTier = value;
    if (dimension === "vibe") this.selectedVibe = value;
    this.renderMarkers();
  },

  resetView() {
    if (!this.mapInstance) return;
    this.mapInstance.setView([20.0, 10.0], 2.3);
  }
};
