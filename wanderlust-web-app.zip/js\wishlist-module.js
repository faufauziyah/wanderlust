/**
 * WanderPulse Travel Wishlist & Bucket List Module
 * Manages saved dream places, visited memories, personal notes, and bucket list budget totals.
 */

const WishlistModule = {
  storageKey: "wanderpulse_wishlist_data",
  items: [], // Array of { destId, status: 'wishlist' | 'visited', priority, targetSeason, personalNotes, userRating, visitedYear, dateAdded }

  init() {
    this.loadFromStorage();
    if (this.items.length === 0) {
      // Add a couple of initial dream destinations to demonstrate functionality
      this.items = [
        {
          destId: "kyoto-japan",
          status: "wishlist",
          priority: "Must Visit Soon",
          targetSeason: "Autumn 2027",
          personalNotes: "Want to photograph the vermilion torii gates at sunrise and stay at a machiya.",
          userRating: 5,
          visitedYear: null,
          dateAdded: new Date().toISOString()
        },
        {
          destId: "bali-indonesia",
          status: "visited",
          priority: "Completed",
          targetSeason: "Summer",
          personalNotes: "The sunsets in Uluwatu and sunrise trek up Mount Batur were absolutely life-changing!",
          userRating: 5,
          visitedYear: 2025,
          dateAdded: new Date().toISOString()
        },
        {
          destId: "amalfi-italy",
          status: "wishlist",
          priority: "Dream Trip",
          targetSeason: "Spring 2028",
          personalNotes: "Hike the Path of the Gods and take a private boat tour to Capri.",
          userRating: 4,
          visitedYear: null,
          dateAdded: new Date().toISOString()
        }
      ];
      this.saveToStorage();
    }
  },

  loadFromStorage() {
    try {
      const saved = localStorage.getItem(this.storageKey);
      if (saved) {
        this.items = JSON.parse(saved);
      }
    } catch (e) {
      console.warn("Could not load wishlist:", e);
      this.items = [];
    }
  },

  saveToStorage() {
    try {
      localStorage.setItem(this.storageKey, JSON.stringify(this.items));
    } catch (e) {
      console.warn("Could not save wishlist:", e);
    }
  },

  isWishlisted(destId) {
    return this.items.some(i => i.destId === destId);
  },

  getItem(destId) {
    return this.items.find(i => i.destId === destId) || null;
  },

  toggleWishlist(destId) {
    const existingIndex = this.items.findIndex(i => i.destId === destId);
    if (existingIndex >= 0) {
      this.items.splice(existingIndex, 1);
      this.saveToStorage();
      return { added: false };
    } else {
      const newItem = {
        destId,
        status: "wishlist",
        priority: "Must Visit Soon",
        targetSeason: "Someday",
        personalNotes: "",
        userRating: 5,
        visitedYear: null,
        dateAdded: new Date().toISOString()
      };
      this.items.unshift(newItem);
      this.saveToStorage();
      return { added: true, item: newItem };
    }
  },

  updateItem(destId, updates) {
    const item = this.items.find(i => i.destId === destId);
    if (item) {
      Object.assign(item, updates);
      this.saveToStorage();
    }
  },

  removeItem(destId) {
    this.items = this.items.filter(i => i.destId !== destId);
    this.saveToStorage();
  },

  calculateBucketListTotal(travelStyle = "midRange", daysPerTrip = 7) {
    let totalUSD = 0;
    const wishlistItems = this.items.filter(i => i.status === "wishlist");

    wishlistItems.forEach(item => {
      const dest = DESTINATIONS.find(d => d.id === item.destId);
      if (dest) {
        const est = BudgetEngine.calculateTripCost({
          destinationId: dest.id,
          days: daysPerTrip,
          travelers: 1,
          travelStyle,
          includeFlights: true
        });
        if (est) {
          totalUSD += est.grandTotalUSD;
        }
      }
    });

    return {
      count: wishlistItems.length,
      totalUSD
    };
  }
};
