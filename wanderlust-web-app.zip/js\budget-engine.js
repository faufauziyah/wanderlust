/**
 * WanderPulse Budget Engine & AI Recommendation Algorithm
 * Calculates granular trip costs and intelligently matches users
 * with the highest-scoring destinations based on their budget and preferences.
 */

const BudgetEngine = {
  currentCurrency: "USD",

  setCurrency(currCode) {
    if (CURRENCIES[currCode]) {
      this.currentCurrency = currCode;
    }
  },

  formatCurrency(amountInUSD, showDecimals = false) {
    const curr = CURRENCIES[this.currentCurrency] || CURRENCIES.USD;
    const converted = amountInUSD * curr.rate;
    
    // Formatting based on magnitude
    const decimals = (showDecimals && converted < 1000) ? 2 : 0;
    const formatted = converted.toLocaleString(undefined, {
      minimumFractionDigits: decimals,
      maximumFractionDigits: decimals
    });

    return `${curr.symbol}${formatted}`;
  },

  /**
   * Calculate detailed trip breakdown for a specific destination
   */
  calculateTripCost({
    destinationId,
    days = 7,
    travelers = 1,
    travelStyle = "midRange", // backpacker, midRange, luxury
    includeFlights = true,
    flightOriginMultiplier = 1.0 // adjustment for home region
  }) {
    const dest = DESTINATIONS.find(d => d.id === destinationId);
    if (!dest) return null;

    const costs = dest.dailyCostsUSD[travelStyle] || dest.dailyCostsUSD.midRange;

    // Lodging: 1 room for 1-2 travelers, 2 rooms for 3-4 travelers
    const roomsCount = Math.ceil(travelers / 2);
    const totalLodging = costs.lodging * roomsCount * days;

    // Food, Local Transport, Activities scale per traveler
    const totalFood = costs.food * travelers * days;
    const totalTransport = costs.transport * travelers * days;
    const totalActivities = costs.activities * travelers * days;

    // Flight estimation per person
    const flightPerPerson = includeFlights ? (dest.baseFlightEstUSD * flightOriginMultiplier) : 0;
    const totalFlights = flightPerPerson * travelers;

    // Subtotal
    const subtotal = totalLodging + totalFood + totalTransport + totalActivities + totalFlights;
    
    // 8% Contingency / safety buffer for unexpected expenses
    const contingencyBuffer = Math.round(subtotal * 0.08);
    const grandTotal = subtotal + contingencyBuffer;

    return {
      destination: dest,
      days,
      travelers,
      travelStyle,
      includeFlights,
      breakdownUSD: {
        flights: Math.round(totalFlights),
        lodging: Math.round(totalLodging),
        food: Math.round(totalFood),
        transport: Math.round(totalTransport),
        activities: Math.round(totalActivities),
        buffer: contingencyBuffer
      },
      subtotalUSD: Math.round(subtotal),
      grandTotalUSD: Math.round(grandTotal),
      dailyPerPersonUSD: Math.round(grandTotal / (days * travelers))
    };
  },

  /**
   * Smart AI / Heuristic Recommendation Engine:
   * Finds the best matching destination given the user's budget and criteria.
   */
  recommendDestinations({
    userBudgetUSD = 2500,
    days = 7,
    travelers = 1,
    travelStyle = "midRange", // "backpacker", "midRange", "luxury", or "any"
    preferredVibe = "All",
    preferredSeason = "All",
    preferredContinent = "All",
    includeFlights = true
  }) {
    const results = [];

    DESTINATIONS.forEach(dest => {
      // If user chose specific continent and it doesn't match, skip or heavily deprioritize
      if (preferredContinent !== "All" && dest.continent !== preferredContinent) {
        return;
      }

      // If style is "any", test the best fitting style for the budget
      const stylesToTest = travelStyle === "any" 
        ? ["backpacker", "midRange", "luxury"] 
        : [travelStyle];

      let bestStyleMatch = null;
      let minDifference = Infinity;

      stylesToTest.forEach(style => {
        const costEst = this.calculateTripCost({
          destinationId: dest.id,
          days,
          travelers,
          travelStyle: style,
          includeFlights
        });

        const diff = Math.abs(costEst.grandTotalUSD - userBudgetUSD);
        if (diff < minDifference) {
          minDifference = diff;
          bestStyleMatch = { style, costEst };
        }
      });

      if (!bestStyleMatch) return;

      const { style, costEst } = bestStyleMatch;
      const totalCost = costEst.grandTotalUSD;
      const budgetRatio = totalCost / userBudgetUSD;

      // 1. Budget Fit Score (0 to 50 points)
      let budgetScore = 0;
      let budgetVerdict = "";

      if (budgetRatio <= 1.0) {
        if (budgetRatio >= 0.80) {
          // Sweet spot: 80% - 100% of budget used effectively
          budgetScore = 50;
          budgetVerdict = "Perfect Budget Sweet Spot";
        } else if (budgetRatio >= 0.60) {
          // 60% - 80%: Excellent value, great leftover savings
          budgetScore = 46;
          budgetVerdict = "Great Value & Leftover Savings";
        } else {
          // Under 60%: Ultra budget friendly
          budgetScore = 42;
          budgetVerdict = "Extreme Bargain (Huge Savings)";
        }
      } else if (budgetRatio <= 1.12) {
        // Up to 12% over budget: minor stretch
        budgetScore = 32;
        budgetVerdict = "Slight Stretch (Within 12%)";
      } else if (budgetRatio <= 1.25) {
        budgetScore = 20;
        budgetVerdict = "Moderate Stretch (Over Budget)";
      } else {
        budgetScore = 5;
        budgetVerdict = "Significantly Over Budget";
      }

      // 2. Vibe Match Score (0 to 25 points)
      let vibeScore = 15; // default moderate score
      if (preferredVibe !== "All") {
        if (dest.vibes.includes(preferredVibe)) {
          vibeScore = 25;
        } else {
          vibeScore = 5;
        }
      }

      // 3. Season Match Score (0 to 15 points)
      let seasonScore = 10;
      if (preferredSeason !== "All") {
        if (dest.bestSeasons.includes(preferredSeason)) {
          seasonScore = 15;
        } else {
          seasonScore = 4;
        }
      }

      // 4. Quality & Safety Rating Score (0 to 10 points)
      const qualityScore = Math.round((dest.safetyRating / 5.0) * 10);

      // Composite Match Score (0 to 100)
      const rawMatchScore = budgetScore + vibeScore + seasonScore + qualityScore;
      const matchScore = Math.min(100, Math.max(10, Math.round(rawMatchScore)));

      // Calculate leftover or shortage
      const budgetSurplusUSD = userBudgetUSD - totalCost;

      // Generate customized "Why this place is best" narrative
      let recommendationReason = "";
      if (budgetSurplusUSD >= 0) {
        recommendationReason = `Fits cleanly within your budget with ${this.formatCurrency(budgetSurplusUSD)} left over for shopping and local excursions.`;
      } else {
        recommendationReason = `Just ${this.formatCurrency(Math.abs(budgetSurplusUSD))} above budget, easily compensated by booking flights early or choosing cozy local guesthouses.`;
      }

      results.push({
        destination: dest,
        matchScore,
        recommendedStyle: style,
        costEstimate: costEst,
        budgetVerdict,
        budgetSurplusUSD,
        recommendationReason,
        isUnderBudget: budgetSurplusUSD >= 0
      });
    });

    // Sort by match score descending, then by budget surplus
    results.sort((a, b) => {
      if (b.matchScore !== a.matchScore) {
        return b.matchScore - a.matchScore;
      }
      return b.budgetSurplusUSD - a.budgetSurplusUSD;
    });

    return results;
  }
};
